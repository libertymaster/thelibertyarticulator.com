from django.urls import path

from . import views

app_name = "references"

urlpatterns = [
    path("", views.source_index, name="index"),
    path("", views.source_index, name="list"),
    path("<slug:slug>/", views.source_detail, name="detail"),
]
