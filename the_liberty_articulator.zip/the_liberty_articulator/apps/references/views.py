from django.core.paginator import Paginator
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, render

from .models import Source
from .selectors import source_list
from .services import render_citation, source_to_csl_json


def source_index(request):
    query = request.GET.get("q", "").strip()
    source_type = request.GET.get("type", "").strip()
    try:
        year = int(request.GET["year"]) if request.GET.get("year") else None
    except ValueError:
        year = None
    sources = source_list(query=query, source_type=source_type, year=year)
    page = Paginator(sources, 24).get_page(request.GET.get("page"))
    return render(
        request,
        "references/source_list.html",
        {
            "page_obj": page,
            "sources": page.object_list,
            "query": query,
            "source_type": source_type,
            "year": year,
            "source_types": Source.Type.choices,
        },
    )


def source_detail(request, slug):
    source = get_object_or_404(Source, slug=slug, is_active=True)
    if request.GET.get("format") == "csl-json":
        return JsonResponse(source_to_csl_json(source))
    return render(
        request,
        "references/source_detail.html",
        {"source": source, "citation": render_citation(source)},
    )
