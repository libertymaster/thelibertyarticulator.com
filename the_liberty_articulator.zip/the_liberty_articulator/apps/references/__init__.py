"""Bibliographic references and citation rendering."""
