from __future__ import annotations

import re
from typing import ClassVar

from django.core.exceptions import ValidationError
from django.db import models
from django.urls import reverse
from django.utils import timezone
from django.utils.text import slugify
from wagtail.admin.panels import FieldPanel, MultiFieldPanel
from wagtail.search import index

from apps.core.models import AuditableModel

DOI_PREFIX_RE = re.compile(r"^(?:https?://(?:dx\.)?doi\.org/|doi:\s*)", re.I)


def normalize_doi(value: str | None) -> str:
    """Normalize common DOI prefixes while intentionally accepting free text."""

    return DOI_PREFIX_RE.sub("", (value or "").strip()).strip()


class Source(index.Indexed, AuditableModel):
    class Type(models.TextChoices):
        ARTICLE = "article-journal", "Journal article"
        BOOK = "book", "Book"
        CHAPTER = "chapter", "Book chapter"
        REPORT = "report", "Report"
        THESIS = "thesis", "Thesis"
        WEBPAGE = "webpage", "Web page"
        NEWSPAPER = "article-newspaper", "Newspaper article"
        MANUSCRIPT = "manuscript", "Manuscript / archival item"
        LEGAL = "legal_case", "Legal material"
        OTHER = "document", "Other document"

    title = models.CharField(max_length=500)
    slug = models.SlugField(max_length=220, unique=True, blank=True)
    source_type = models.CharField(max_length=30, choices=Type.choices, default=Type.OTHER)
    authors = models.JSONField(
        default=list,
        blank=True,
        help_text=(
            'CSL-style names, e.g. [{"family": "Locke", "given": "John"}]. '
            "Strings are also accepted."
        ),
    )
    editors = models.JSONField(default=list, blank=True)
    container_title = models.CharField(
        max_length=300,
        blank=True,
        help_text="Journal, newspaper, archive, or collection.",
    )
    publisher = models.CharField(max_length=240, blank=True)
    publisher_place = models.CharField(max_length=180, blank=True)
    publication_year = models.PositiveSmallIntegerField(blank=True, null=True, db_index=True)
    publication_date = models.DateField(blank=True, null=True)
    accessed_date = models.DateField(blank=True, null=True)
    volume = models.CharField(max_length=40, blank=True)
    issue = models.CharField(max_length=40, blank=True)
    pages = models.CharField(max_length=80, blank=True)
    edition = models.CharField(max_length=80, blank=True)
    doi = models.CharField(
        max_length=300,
        blank=True,
        help_text="Free-text DOI; URL and doi: prefixes are removed on save.",
    )
    isbn = models.CharField(max_length=40, blank=True)
    url = models.URLField(max_length=1000, blank=True)
    citation_key = models.SlugField(max_length=160, unique=True, blank=True)
    abstract = models.TextField(blank=True)
    notes = models.TextField(blank=True)
    is_active = models.BooleanField(default=True, db_index=True)

    panels: ClassVar[list] = [
        FieldPanel("title"),
        FieldPanel("slug"),
        FieldPanel("source_type"),
        FieldPanel("authors"),
        FieldPanel("editors"),
        MultiFieldPanel(
            [
                FieldPanel("container_title"),
                FieldPanel("volume"),
                FieldPanel("issue"),
                FieldPanel("pages"),
            ],
            heading="Container",
        ),
        MultiFieldPanel(
            [
                FieldPanel("publisher"),
                FieldPanel("publisher_place"),
                FieldPanel("edition"),
            ],
            heading="Publication",
        ),
        MultiFieldPanel(
            [
                FieldPanel("publication_year"),
                FieldPanel("publication_date"),
                FieldPanel("accessed_date"),
            ],
            heading="Dates",
        ),
        MultiFieldPanel(
            [
                FieldPanel("doi"),
                FieldPanel("isbn"),
                FieldPanel("url"),
                FieldPanel("citation_key"),
            ],
            heading="Identifiers",
        ),
        FieldPanel("abstract"),
        FieldPanel("notes"),
        FieldPanel("is_active"),
    ]
    search_fields: ClassVar[list] = [
        index.SearchField("title", partial_match=True, boost=3),
        index.SearchField("container_title", partial_match=True, boost=2),
        index.SearchField("publisher", partial_match=True),
        index.SearchField("abstract"),
        index.SearchField("doi", partial_match=True),
        index.FilterField("source_type"),
        index.FilterField("publication_year"),
        index.FilterField("is_active"),
    ]

    class Meta:
        ordering = ("title",)
        indexes: ClassVar[list] = [
            models.Index(fields=("source_type", "publication_year"), name="source_type_year_idx"),
        ]

    def __str__(self) -> str:
        return self.title

    @property
    def doi_url(self) -> str:
        return f"https://doi.org/{self.doi}" if self.doi else ""

    @property
    def year(self):
        return self.publication_year

    @property
    def formatted_citation(self) -> str:
        from .services import render_citation

        return render_citation(self)

    @property
    def cited_by(self):
        return self.publication_citations

    @property
    def csl_json(self) -> dict:
        from .services import source_to_csl_json

        return source_to_csl_json(self)

    def clean(self) -> None:
        super().clean()
        if (
            self.publication_date
            and self.publication_year
            and self.publication_date.year != self.publication_year
        ):
            raise ValidationError(
                {"publication_year": "Year must match the full publication date."}
            )
        current_year = timezone.now().year + 5
        if self.publication_year and self.publication_year > current_year:
            raise ValidationError(
                {"publication_year": "Publication year is implausibly far in the future."}
            )
        if not isinstance(self.authors, list):
            raise ValidationError({"authors": "Authors must be a JSON list."})
        if not isinstance(self.editors, list):
            raise ValidationError({"editors": "Editors must be a JSON list."})

    def save(self, *args, **kwargs):
        self.doi = normalize_doi(self.doi)
        if self.publication_date and not self.publication_year:
            self.publication_year = self.publication_date.year
        if not self.slug:
            self.slug = self._unique_slug(slugify(self.title)[:190] or "source", "slug", 220)
        if not self.citation_key:
            author = "source"
            if self.authors:
                first = self.authors[0]
                if isinstance(first, dict):
                    author = first.get("family") or first.get("literal") or "source"
                else:
                    author = str(first)
            key_text = f"{author}-{self.publication_year or 'nd'}-{self.title[:50]}"
            base = slugify(key_text) or "source"
            self.citation_key = self._unique_slug(base[:140], "citation_key", 160)
        return super().save(*args, **kwargs)

    def _unique_slug(self, base: str, field: str, max_length: int) -> str:
        candidate = base
        counter = 2
        manager = type(self).objects.exclude(pk=self.pk)
        while manager.filter(**{field: candidate}).exists():
            suffix = f"-{counter}"
            candidate = f"{base[: max_length - len(suffix)]}{suffix}"
            counter += 1
        return candidate

    def get_absolute_url(self) -> str:
        return reverse("references:detail", kwargs={"slug": self.slug})
