from typing import ClassVar

from django.contrib import admin

from .models import Source


@admin.register(Source)
class SourceAdmin(admin.ModelAdmin):
    list_display = ("title", "source_type", "publication_year", "doi", "is_active")
    list_filter = ("source_type", "publication_year", "is_active")
    prepopulated_fields: ClassVar[dict[str, tuple[str, ...]]] = {"slug": ("title",)}
    search_fields = ("title", "container_title", "publisher", "doi", "citation_key")
