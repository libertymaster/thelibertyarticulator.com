import django.db.models.deletion
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = [migrations.swappable_dependency(settings.AUTH_USER_MODEL)]

    operations = [
        migrations.CreateModel(
            name="Source",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True, db_index=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("title", models.CharField(max_length=500)),
                ("slug", models.SlugField(blank=True, max_length=220, unique=True)),
                ("source_type", models.CharField(choices=[("article-journal", "Journal article"), ("book", "Book"), ("chapter", "Book chapter"), ("report", "Report"), ("thesis", "Thesis"), ("webpage", "Web page"), ("article-newspaper", "Newspaper article"), ("manuscript", "Manuscript / archival item"), ("legal_case", "Legal material"), ("document", "Other document")], default="document", max_length=30)),
                ("authors", models.JSONField(blank=True, default=list, help_text='CSL-style names, e.g. [{"family": "Locke", "given": "John"}]. Strings are also accepted.')),
                ("editors", models.JSONField(blank=True, default=list)),
                ("container_title", models.CharField(blank=True, help_text="Journal, newspaper, archive, or collection.", max_length=300)),
                ("publisher", models.CharField(blank=True, max_length=240)),
                ("publisher_place", models.CharField(blank=True, max_length=180)),
                ("publication_year", models.PositiveSmallIntegerField(blank=True, db_index=True, null=True)),
                ("publication_date", models.DateField(blank=True, null=True)),
                ("accessed_date", models.DateField(blank=True, null=True)),
                ("volume", models.CharField(blank=True, max_length=40)),
                ("issue", models.CharField(blank=True, max_length=40)),
                ("pages", models.CharField(blank=True, max_length=80)),
                ("edition", models.CharField(blank=True, max_length=80)),
                ("doi", models.CharField(blank=True, help_text="Free-text DOI; URL and doi: prefixes are removed on save.", max_length=300)),
                ("isbn", models.CharField(blank=True, max_length=40)),
                ("url", models.URLField(blank=True, max_length=1000)),
                ("citation_key", models.SlugField(blank=True, max_length=160, unique=True)),
                ("abstract", models.TextField(blank=True)),
                ("notes", models.TextField(blank=True)),
                ("is_active", models.BooleanField(db_index=True, default=True)),
                ("created_by", models.ForeignKey(blank=True, editable=False, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="references_source_created", to=settings.AUTH_USER_MODEL)),
                ("updated_by", models.ForeignKey(blank=True, editable=False, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="references_source_updated", to=settings.AUTH_USER_MODEL)),
            ],
            options={"ordering": ("title",), "indexes": [models.Index(fields=["source_type", "publication_year"], name="source_type_year_idx")]},
        )
    ]

