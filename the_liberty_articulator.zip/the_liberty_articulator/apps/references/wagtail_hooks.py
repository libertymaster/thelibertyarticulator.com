from wagtail import hooks
from wagtail.snippets.views.snippets import SnippetViewSet

from .models import Source


class SourceViewSet(SnippetViewSet):
    model = Source
    icon = "doc-full"
    menu_label = "Sources"
    list_display = ("title", "source_type", "publication_year", "doi", "is_active")
    list_filter = ("source_type", "publication_year", "is_active")
    search_fields = ("title", "container_title", "doi", "citation_key")


@hooks.register("register_admin_viewset")
def register_source_viewset():
    return SourceViewSet(name="sources")
