from __future__ import annotations

from django.db.models import Q, QuerySet

from .models import Source


def source_list(
    *,
    query: str = "",
    source_type: str = "",
    year: int | None = None,
    include_inactive: bool = False,
) -> QuerySet[Source]:
    sources = Source.objects.all()
    if not include_inactive:
        sources = sources.filter(is_active=True)
    if query:
        sources = sources.filter(
            Q(title__icontains=query)
            | Q(container_title__icontains=query)
            | Q(publisher__icontains=query)
            | Q(doi__icontains=query)
            | Q(citation_key__icontains=query)
        )
    if source_type:
        sources = sources.filter(source_type=source_type)
    if year:
        sources = sources.filter(publication_year=year)
    return sources.order_by("title")
