from __future__ import annotations

import html
from collections.abc import Iterable
from pathlib import Path

from django.conf import settings


def _csl_names(values: Iterable[object]) -> list[dict]:
    names: list[dict] = []
    for value in values or []:
        if isinstance(value, dict):
            allowed = {
                key: value[key]
                for key in ("family", "given", "literal", "suffix")
                if value.get(key)
            }
            if allowed:
                names.append(allowed)
        elif str(value).strip():
            names.append({"literal": str(value).strip()})
    return names


def source_to_csl_json(source) -> dict:
    """Return portable CSL-JSON suitable for citeproc and exports."""

    issued = source.publication_date
    if issued:
        date_parts = [issued.year, issued.month, issued.day]
    else:
        date_parts = [source.publication_year] if source.publication_year else []
    payload = {
        "id": source.citation_key or str(source.pk),
        "type": source.source_type,
        "title": source.title,
        "author": _csl_names(source.authors),
        "editor": _csl_names(source.editors),
        "container-title": source.container_title,
        "publisher": source.publisher,
        "publisher-place": source.publisher_place,
        "volume": source.volume,
        "issue": source.issue,
        "page": source.pages,
        "edition": source.edition,
        "DOI": source.doi,
        "ISBN": source.isbn,
        "URL": source.url,
    }
    if date_parts:
        payload["issued"] = {"date-parts": [date_parts]}
    if source.accessed_date:
        payload["accessed"] = {
            "date-parts": [
                [
                    source.accessed_date.year,
                    source.accessed_date.month,
                    source.accessed_date.day,
                ]
            ]
        }
    return {key: value for key, value in payload.items() if value not in ("", [], None)}


def _display_names(values: Iterable[object]) -> str:
    rendered: list[str] = []
    for value in values or []:
        if isinstance(value, dict):
            name = value.get("literal") or ", ".join(
                part for part in (value.get("family", ""), value.get("given", "")) if part
            )
            rendered.append(name)
        else:
            rendered.append(str(value))
    rendered = [value.strip() for value in rendered if value and value.strip()]
    if len(rendered) > 3:
        return f"{rendered[0]} et al."
    if len(rendered) == 2:
        return " and ".join(rendered)
    return ", ".join(rendered)


def _builtin_citation(source, style: str) -> str:
    author = _display_names(source.authors or source.editors) or "Anonymous"
    year = str(source.publication_year or "n.d.")
    title = source.title.rstrip(".")
    container = source.container_title.rstrip(".")
    locator = source.doi_url or source.url
    if style.lower().startswith("mla"):
        pieces = [
            f"{author}.",
            f"“{title}.”" if container else f"{title}.",
            f"{container}," if container else "",
            f"{year}.",
            locator,
        ]
    elif style.lower().startswith("chicago"):
        pieces = [
            f"{author}.",
            f"“{title}.”" if container else f"{title}.",
            f"{container}." if container else "",
            f"{year}.",
            locator,
        ]
    else:  # APA-like, deliberately readable even without citeproc styles installed.
        pieces = [f"{author} ({year}).", f"{title}.", f"{container}." if container else "", locator]
    return " ".join(piece for piece in pieces if piece).strip()


def _citeproc_citation(source, style: str) -> str | None:
    style_paths = getattr(settings, "CSL_STYLE_PATHS", {})
    style_path = style_paths.get(style) if isinstance(style_paths, dict) else None
    if not style_path or not Path(style_path).is_file():
        return None
    try:
        from citeproc import (
            Citation,
            CitationItem,
            CitationStylesBibliography,
            CitationStylesStyle,
            formatter,
        )
        from citeproc.source.json import CiteProcJSON
    except ImportError:
        return None
    payload = source_to_csl_json(source)
    bibliography = CitationStylesBibliography(
        CitationStylesStyle(style_path, validate=False),
        CiteProcJSON([payload]),
        formatter.plain,
    )
    bibliography.register(Citation([CitationItem(payload["id"])]))
    entries = bibliography.bibliography()
    return str(entries[0]) if entries else None


def render_citation(source, style: str = "apa", *, html_output: bool = False) -> str:
    """Render a source via configured CSL, with a deterministic local fallback."""

    rendered = _citeproc_citation(source, style) or _builtin_citation(source, style)
    return html.escape(rendered) if html_output else rendered
