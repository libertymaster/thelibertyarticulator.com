from __future__ import annotations

from datetime import timedelta

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction
from django.utils import timezone
from wagtail.models import Page, Site

from apps.people.models import Person
from apps.publications.models import Contributor, PublicationPage, PublicationSource
from apps.publications.services import create_version
from apps.references.models import Source
from apps.series.models import Series
from apps.taxonomy.models import Category, Keyword


class Command(BaseCommand):
    help = "Create or refresh a polished, idempotent demonstration journal."

    @transaction.atomic
    def handle(self, *args, **options):
        people = self._seed_people()
        categories, keywords = self._seed_taxonomy()
        sources = self._seed_sources()
        series = self._seed_series(people)
        parent = self._publication_parent()

        now = timezone.now()
        records = [
            {
                "slug": "the-long-argument-for-liberty",
                "title": "The Long Argument for Liberty",
                "subtitle": "Natural rights are inherited through debate, not repetition",
                "dek": (
                    "A close reading of liberty as a living argument—one that each "
                    "generation must test against power, experience, and conscience."
                ),
                "abstract": (
                    "Liberty survives when its claims remain open to scrutiny. This essay "
                    "returns to Locke while asking what a rights tradition owes the people "
                    "excluded from its earliest formulations."
                ),
                "body": (
                    '<p class="lead">The language of natural rights can sound settled '
                    "only when history is kept outside the room.</p>"
                    "<h2>A claim larger than its first claimants</h2>"
                    "<p>Locke supplied a grammar for limits on political power, but a "
                    "grammar is not yet a just society. Its nouns—person, consent, "
                    "property—have been contested ever since.</p>"
                    "<blockquote>Traditions of liberty endure by surviving their most "
                    "demanding readers.</blockquote>"
                    "<h2>Inheritance as responsibility</h2>"
                    "<p>To inherit an argument is to receive unfinished work. Close "
                    "reading lets us distinguish a principle from the compromises that "
                    "once surrounded it.</p>"
                ),
                "publication_type": PublicationPage.Type.ESSAY,
                "published_at": now - timedelta(days=42),
                "featured": True,
                "peer_reviewed": False,
                "series": series["architecture"],
                "contributors": [(people["hart"], Contributor.Role.AUTHOR)],
                "categories": [categories["rights"]],
                "keywords": [keywords["natural-rights"], keywords["consent"]],
                "sources": [(sources["locke"], "II, §§4-15")],
            },
            {
                "slug": "power-divided-freedom-preserved",
                "title": "Power Divided, Freedom Preserved?",
                "subtitle": "What separation of powers can—and cannot—promise",
                "dek": (
                    "Constitutional structure slows power down. Whether it protects liberty "
                    "depends on the habits and incentives operating inside it."
                ),
                "abstract": (
                    "A historical analysis of separated powers as a practical discipline "
                    "rather than a self-executing safeguard."
                ),
                "body": (
                    '<p class="lead">A constitution is a machine made of human '
                    "judgment.</p>"
                    "<h2>Friction by design</h2>"
                    "<p>Montesquieu did not offer a diagram that could govern by itself. "
                    "He described relationships in which ambition, law, and civic custom "
                    "could keep authority from becoming singular.</p>"
                    "<h2>The limits of architecture</h2>"
                    "<p>Institutions buy time for resistance and reconsideration. They do "
                    "not relieve citizens or officials of the duty to use that time well.</p>"
                ),
                "publication_type": PublicationPage.Type.ANALYSIS,
                "published_at": now - timedelta(days=27),
                "featured": True,
                "peer_reviewed": True,
                "series": series["architecture"],
                "contributors": [(people["ellison"], Contributor.Role.AUTHOR)],
                "categories": [categories["government"]],
                "keywords": [keywords["separation"], keywords["institutions"]],
                "sources": [(sources["montesquieu"], "Book XI, chapter 6")],
            },
            {
                "slug": "frederick-douglass-and-moral-memory",
                "title": "Frederick Douglass and the Moral Uses of Memory",
                "subtitle": "The past becomes civic evidence when ceremony is not enough",
                "dek": (
                    "Douglass transformed commemoration into cross-examination, showing "
                    "how historical memory can expose the distance between creed and fact."
                ),
                "abstract": (
                    "Reading the 1852 Fourth of July address as a method for responsible "
                    "public memory."
                ),
                "body": (
                    '<p class="lead">Douglass entered a national celebration and '
                    "changed the question being celebrated.</p>"
                    "<h2>Commemoration under examination</h2>"
                    "<p>His address did not reject the revolutionary promise. It made that "
                    "promise testify against the republic's present conduct.</p>"
                    "<h2>Memory with a moral purpose</h2>"
                    "<p>Historical memory becomes civic evidence when it preserves both "
                    "aspiration and injury. Without both, remembrance becomes decoration.</p>"
                ),
                "publication_type": PublicationPage.Type.ARTICLE,
                "published_at": now - timedelta(days=13),
                "featured": True,
                "peer_reviewed": False,
                "series": series["archive"],
                "contributors": [(people["reyes"], Contributor.Role.AUTHOR)],
                "categories": [categories["memory"], categories["rights"]],
                "keywords": [keywords["memory"], keywords["primary-sources"]],
                "sources": [(sources["douglass"], "paras. 3-7, 32-35")],
            },
            {
                "slug": "reading-the-record-against-the-grain",
                "title": "Reading the Record Against the Grain",
                "subtitle": "A field guide to evidence, silence, and historical confidence",
                "dek": (
                    "Sources tell us what survived, not everything that happened. A better "
                    "historical method begins by noticing the difference."
                ),
                "abstract": (
                    "A practical guide to weighing primary sources without treating archival "
                    "survival as neutral or absence as proof."
                ),
                "body": (
                    '<p class="lead">Every archive is both a collection and a pattern '
                    "of loss.</p>"
                    "<h2>Begin with provenance</h2>"
                    "<p>Ask who created the record, for whom, under what constraints, and "
                    "by what route it reached the present.</p>"
                    "<h2>Calibrate the claim</h2>"
                    "<p>The responsible historian matches confidence to evidence. Honest "
                    "uncertainty is not a defect; it is part of the finding.</p>"
                ),
                "publication_type": PublicationPage.Type.ARTICLE,
                "published_at": now - timedelta(days=4),
                "featured": False,
                "peer_reviewed": False,
                "series": series["archive"],
                "contributors": [
                    (people["hart"], Contributor.Role.AUTHOR),
                    (people["reyes"], Contributor.Role.RESEARCHER),
                ],
                "categories": [categories["memory"]],
                "keywords": [keywords["primary-sources"], keywords["method"]],
                "sources": [(sources["trouillot"], "chapters 1-2")],
            },
        ]

        created = 0
        updated = 0
        for record in records:
            was_created = self._seed_publication(parent, record)
            created += int(was_created)
            updated += int(not was_created)

        self.stdout.write(
            self.style.SUCCESS(
                f"Demo journal ready: {created} publications created, "
                f"{updated} refreshed, {len(records)} total."
            )
        )

    def _seed_people(self) -> dict[str, Person]:
        records = {
            "hart": {
                "name": "Dr. Eleanor Hart",
                "given_name": "Eleanor",
                "family_name": "Hart",
                "affiliation": "Center for the Study of Constitutional Traditions",
                "biography": (
                    "<p>Eleanor Hart writes about natural rights, political obligation, "
                    "and the afterlives of early modern political thought.</p>"
                ),
            },
            "ellison": {
                "name": "Marcus Ellison",
                "given_name": "Marcus",
                "family_name": "Ellison",
                "affiliation": "Independent constitutional historian",
                "biography": (
                    "<p>Marcus Ellison studies constitutional design and the practical "
                    "conditions under which institutions restrain public power.</p>"
                ),
            },
            "reyes": {
                "name": "Sofia Reyes",
                "given_name": "Sofia",
                "family_name": "Reyes",
                "affiliation": "Public Memory Project",
                "biography": (
                    "<p>Sofia Reyes researches civic memory, archives, and the rhetoric of "
                    "democratic commemoration.</p>"
                ),
            },
        }
        return {
            key: Person.objects.update_or_create(
                slug=key.replace("hart", "eleanor-hart")
                .replace("ellison", "marcus-ellison")
                .replace("reyes", "sofia-reyes"),
                defaults={**values, "is_active": True},
            )[0]
            for key, values in records.items()
        }

    def _seed_taxonomy(self):
        category_data = {
            "rights": ("Liberty & Natural Rights", "liberty-natural-rights"),
            "government": ("Constitutional Government", "constitutional-government"),
            "memory": ("History & Civic Memory", "history-civic-memory"),
        }
        categories = {
            key: Category.objects.update_or_create(
                slug=slug,
                defaults={"name": name, "description": "", "is_active": True},
            )[0]
            for key, (name, slug) in category_data.items()
        }
        keyword_data = {
            "natural-rights": "Natural Rights",
            "consent": "Consent",
            "separation": "Separation of Powers",
            "institutions": "Institutions",
            "memory": "Civic Memory",
            "primary-sources": "Primary Sources",
            "method": "Historical Method",
        }
        keywords = {
            key: Keyword.objects.update_or_create(
                slug=key,
                defaults={"name": name, "description": "", "is_active": True},
            )[0]
            for key, name in keyword_data.items()
        }
        return categories, keywords

    def _seed_sources(self) -> dict[str, Source]:
        records = {
            "locke": {
                "slug": "locke-second-treatise",
                "citation_key": "locke-1690-second-treatise",
                "title": "Second Treatise of Government",
                "source_type": Source.Type.BOOK,
                "authors": [{"family": "Locke", "given": "John"}],
                "publisher": "Awnsham Churchill",
                "publisher_place": "London",
                "publication_year": 1690,
            },
            "montesquieu": {
                "slug": "montesquieu-spirit-of-laws",
                "citation_key": "montesquieu-1748-spirit-laws",
                "title": "The Spirit of the Laws",
                "source_type": Source.Type.BOOK,
                "authors": [{"literal": "Montesquieu"}],
                "publication_year": 1748,
            },
            "douglass": {
                "slug": "douglass-what-to-slave-fourth-july",
                "citation_key": "douglass-1852-fourth-july",
                "title": "What to the Slave Is the Fourth of July?",
                "source_type": Source.Type.MANUSCRIPT,
                "authors": [{"family": "Douglass", "given": "Frederick"}],
                "publication_year": 1852,
                "url": "https://www.loc.gov/resource/mfd.21039/",
            },
            "trouillot": {
                "slug": "trouillot-silencing-the-past",
                "citation_key": "trouillot-1995-silencing-past",
                "title": "Silencing the Past: Power and the Production of History",
                "source_type": Source.Type.BOOK,
                "authors": [
                    {"family": "Trouillot", "given": "Michel-Rolph"},
                ],
                "publisher": "Beacon Press",
                "publication_year": 1995,
                "isbn": "978-0-8070-4311-0",
            },
        }
        sources = {}
        for key, values in records.items():
            slug = values["slug"]
            defaults = {**values, "is_active": True}
            defaults.pop("slug")
            sources[key] = Source.objects.update_or_create(slug=slug, defaults=defaults)[0]
        return sources

    def _seed_series(self, people: dict[str, Person]) -> dict[str, Series]:
        records = {
            "architecture": {
                "slug": "architecture-of-freedom",
                "title": "The Architecture of Freedom",
                "tagline": "How institutions shape the space in which liberty lives",
                "description": (
                    "<p>A series examining constitutional forms, political incentives, "
                    "and the human habits that make limited government possible.</p>"
                ),
                "editor": people["ellison"],
                "start_year": 2026,
            },
            "archive": {
                "slug": "the-living-archive",
                "title": "The Living Archive",
                "tagline": "Primary sources and the difficult work of public memory",
                "description": (
                    "<p>Close readings of the records through which a society remembers, "
                    "forgets, and revises its account of itself.</p>"
                ),
                "editor": people["reyes"],
                "start_year": 2026,
            },
        }
        result = {}
        for key, values in records.items():
            slug = values["slug"]
            defaults = {**values, "is_active": True}
            defaults.pop("slug")
            result[key] = Series.objects.update_or_create(slug=slug, defaults=defaults)[0]
        return result

    def _publication_parent(self) -> Page:
        site = Site.objects.filter(is_default_site=True).select_related("root_page").first()
        return site.root_page if site else Page.get_first_root_node()

    def _seed_publication(self, parent: Page, record: dict) -> bool:
        slug = record["slug"]
        publication = PublicationPage.objects.filter(slug=slug).first()
        created = publication is None
        page_values = {
            key: value
            for key, value in record.items()
            if key not in {"contributors", "categories", "keywords", "sources"}
        }
        page_values.update(
            editorial_status=PublicationPage.EditorialStatus.PUBLISHED,
            embargo_until=None,
            live=True,
            search_description=record["dek"][:255],
        )
        changed = created
        if created:
            conflict = parent.get_children().filter(slug=slug).first()
            if conflict:
                raise CommandError(f"Cannot seed {slug}: a non-publication page uses that slug.")
            publication = PublicationPage(**page_values)
            parent.add_child(instance=publication)
        else:
            changed_fields = []
            for field, value in page_values.items():
                # Preserve the original relative demo date across later runs.
                if field == "published_at":
                    continue
                current = getattr(publication, field)
                if field == "body":
                    current = str(current)
                if current != value:
                    setattr(publication, field, value)
                    changed_fields.append(field)
            if changed_fields:
                publication.save(update_fields=changed_fields)
                changed = True

        category_ids = {item.pk for item in record["categories"]}
        keyword_ids = {item.pk for item in record["keywords"]}
        if set(publication.categories.values_list("pk", flat=True)) != category_ids:
            publication.categories.set(record["categories"])
            changed = True
        if set(publication.keywords.values_list("pk", flat=True)) != keyword_ids:
            publication.keywords.set(record["keywords"])
            changed = True

        for sort_order, (person, role) in enumerate(record["contributors"]):
            contribution, relation_created = Contributor.objects.get_or_create(
                publication=publication,
                person=person,
                role=role,
                defaults={"sort_order": sort_order},
            )
            if contribution.sort_order != sort_order:
                contribution.sort_order = sort_order
                contribution.save(update_fields=("sort_order",))
                changed = True
            changed = changed or relation_created

        for sort_order, (source, locator) in enumerate(record["sources"]):
            citation, relation_created = PublicationSource.objects.get_or_create(
                publication=publication,
                source=source,
                locator=locator,
                defaults={"sort_order": sort_order},
            )
            if citation.sort_order != sort_order:
                citation.sort_order = sort_order
                citation.save(update_fields=("sort_order",))
                changed = True
            changed = changed or relation_created

        if changed or not publication.live:
            revision = publication.save_revision(log_action=True)
            revision.publish()
            publication.refresh_from_db()
            create_version(publication, change_summary="Demo content seed")
        return created
