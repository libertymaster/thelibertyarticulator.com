"""Shared domain primitives and operational endpoints."""
