from __future__ import annotations

import re
from urllib.parse import urljoin

from django.conf import settings

_WHITESPACE_RE = re.compile(r"\s+")


def compact_whitespace(value: str | None) -> str:
    """Collapse user-entered whitespace while preserving ordinary text."""

    return _WHITESPACE_RE.sub(" ", value or "").strip()


def site_url(path: str = "/") -> str:
    """Build an absolute public URL without requiring a request object."""

    base = getattr(settings, "PUBLIC_BASE_URL", "http://localhost:8000").rstrip("/") + "/"
    return urljoin(base, path.lstrip("/"))


def client_ip(request) -> str | None:
    """Return the originating IP, honoring proxies only when explicitly enabled."""

    if getattr(settings, "TRUST_X_FORWARDED_FOR", False):
        forwarded = request.META.get("HTTP_X_FORWARDED_FOR", "")
        if forwarded:
            return forwarded.split(",", 1)[0].strip()
    return request.META.get("REMOTE_ADDR")
