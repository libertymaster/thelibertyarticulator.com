from django.conf import settings


def site_identity(request):
    return {
        "site_name": getattr(settings, "WAGTAIL_SITE_NAME", "The Liberty Articulator"),
        "public_base_url": getattr(settings, "PUBLIC_BASE_URL", ""),
    }
