from __future__ import annotations

import re
import uuid

from django.utils.deprecation import MiddlewareMixin


class RequestIDMiddleware(MiddlewareMixin):
    """Attach a safe request identifier and echo it in the response."""

    header_name = "HTTP_X_REQUEST_ID"
    safe_id = re.compile(r"[A-Za-z0-9._-]{1,128}\Z")

    def process_request(self, request):
        supplied = request.META.get(self.header_name, "")
        request.request_id = supplied if self.safe_id.fullmatch(supplied) else uuid.uuid4().hex

    def process_response(self, request, response):
        response["X-Request-ID"] = getattr(request, "request_id", uuid.uuid4().hex)
        return response


class SecurityHeadersMiddleware(MiddlewareMixin):
    """Add application-specific browser defenses not covered by Django settings."""

    def process_response(self, request, response):
        response.setdefault(
            "Permissions-Policy", "camera=(), microphone=(), geolocation=(), payment=()"
        )
        response.setdefault("Cross-Origin-Opener-Policy", "same-origin")
        response.setdefault("X-Permitted-Cross-Domain-Policies", "none")
        return response
