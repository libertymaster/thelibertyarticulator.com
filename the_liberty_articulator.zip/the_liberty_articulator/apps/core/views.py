from __future__ import annotations

import time

from django.core.cache import cache
from django.db import connection
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import render
from django.views.decorators.cache import never_cache
from django.views.decorators.http import require_GET


@require_GET
@never_cache
def health(request: HttpRequest) -> JsonResponse:
    """Liveness endpoint: a response proves the Django process is serving."""

    return JsonResponse({"status": "ok"})


@require_GET
@never_cache
def ready(request: HttpRequest) -> JsonResponse:
    """Readiness endpoint checking dependencies required to serve traffic."""

    checks: dict[str, str] = {}
    try:
        with connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            cursor.fetchone()
        checks["database"] = "ok"
    except Exception as exc:  # pragma: no cover - backend-specific failures
        checks["database"] = exc.__class__.__name__

    try:
        probe = f"readiness:{time.monotonic_ns()}"
        cache.set(probe, "ok", timeout=5)
        checks["cache"] = "ok" if cache.get(probe) == "ok" else "unavailable"
        cache.delete(probe)
    except Exception as exc:  # pragma: no cover - backend-specific failures
        checks["cache"] = exc.__class__.__name__

    is_ready = all(value == "ok" for value in checks.values())
    return JsonResponse(
        {"status": "ready" if is_ready else "not_ready", "checks": checks},
        status=200 if is_ready else 503,
    )


@require_GET
@never_cache
def metrics(request: HttpRequest) -> HttpResponse:
    """Expose Prometheus metrics when the optional client is installed."""

    try:
        from prometheus_client import CONTENT_TYPE_LATEST, generate_latest
    except ImportError:
        body = (
            "# HELP articulator_up Whether the web process is running.\n"
            "# TYPE articulator_up gauge\n"
            "articulator_up 1\n"
        )
        return HttpResponse(body, content_type="text/plain; version=0.0.4")
    return HttpResponse(generate_latest(), content_type=CONTENT_TYPE_LATEST)


def error_404(request: HttpRequest, exception=None) -> HttpResponse:
    return render(request, "404.html", status=404)


def error_500(request: HttpRequest) -> HttpResponse:
    return render(request, "500.html", status=500)
