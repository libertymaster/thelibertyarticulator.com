"""First-party applications."""
