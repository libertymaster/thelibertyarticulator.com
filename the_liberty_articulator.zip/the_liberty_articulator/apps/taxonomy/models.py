from __future__ import annotations

from typing import ClassVar

from django.core.exceptions import ValidationError
from django.db import models
from django.urls import reverse
from wagtail.admin.panels import FieldPanel
from wagtail.search import index

from apps.core.models import AuditableModel


class Category(index.Indexed, AuditableModel):
    name = models.CharField(max_length=120)
    slug = models.SlugField(max_length=140, unique=True)
    description = models.TextField(blank=True)
    parent = models.ForeignKey(
        "self",
        blank=True,
        null=True,
        on_delete=models.PROTECT,
        related_name="children",
    )
    sort_order = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True, db_index=True)

    panels: ClassVar[list] = [
        FieldPanel("name"),
        FieldPanel("slug"),
        FieldPanel("description"),
        FieldPanel("parent"),
        FieldPanel("sort_order"),
        FieldPanel("is_active"),
    ]
    search_fields: ClassVar[list] = [
        index.SearchField("name", partial_match=True, boost=2),
        index.SearchField("description"),
        index.FilterField("is_active"),
    ]

    class Meta:
        ordering = ("sort_order", "name")
        verbose_name_plural = "categories"

    def __str__(self) -> str:
        return " / ".join(item.name for item in self.ancestors(include_self=True))

    def clean(self) -> None:
        super().clean()
        if self.parent_id and self.parent_id == self.pk:
            raise ValidationError({"parent": "A category cannot be its own parent."})
        cursor = self.parent
        seen = {self.pk} if self.pk else set()
        while cursor is not None:
            if cursor.pk in seen:
                raise ValidationError({"parent": "Category ancestry cannot contain a cycle."})
            seen.add(cursor.pk)
            cursor = cursor.parent

    def ancestors(self, *, include_self: bool = False) -> list[Category]:
        nodes: list[Category] = [self] if include_self else []
        cursor = self.parent
        while cursor is not None:
            nodes.append(cursor)
            cursor = cursor.parent
        nodes.reverse()
        return nodes

    def get_absolute_url(self) -> str:
        return f"{reverse('publications:index')}?category={self.slug}"


class Keyword(index.Indexed, AuditableModel):
    name = models.CharField(max_length=100, unique=True)
    slug = models.SlugField(max_length=120, unique=True)
    description = models.TextField(blank=True)
    is_active = models.BooleanField(default=True, db_index=True)

    panels: ClassVar[list] = [
        FieldPanel("name"),
        FieldPanel("slug"),
        FieldPanel("description"),
        FieldPanel("is_active"),
    ]
    search_fields: ClassVar[list] = [
        index.SearchField("name", partial_match=True, boost=2),
        index.SearchField("description"),
        index.FilterField("is_active"),
    ]

    class Meta:
        ordering = ("name",)

    def __str__(self) -> str:
        return self.name

    def get_absolute_url(self) -> str:
        return f"{reverse('publications:index')}?keyword={self.slug}"
