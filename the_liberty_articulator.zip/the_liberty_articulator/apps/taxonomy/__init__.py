"""Hierarchical categories and flat keywords."""
