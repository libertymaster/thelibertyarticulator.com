from wagtail import hooks
from wagtail.snippets.views.snippets import SnippetViewSet

from .models import Category, Keyword


class CategoryViewSet(SnippetViewSet):
    model = Category
    icon = "folder-open-inverse"
    menu_label = "Categories"
    list_display = ("name", "parent", "is_active")
    list_filter = ("is_active",)
    search_fields = ("name", "description")


class KeywordViewSet(SnippetViewSet):
    model = Keyword
    icon = "tag"
    menu_label = "Keywords"
    list_display = ("name", "is_active")
    list_filter = ("is_active",)
    search_fields = ("name", "description")


@hooks.register("register_admin_viewset")
def register_taxonomy_viewsets():
    return [
        CategoryViewSet(name="categories"),
        KeywordViewSet(name="keywords"),
    ]
