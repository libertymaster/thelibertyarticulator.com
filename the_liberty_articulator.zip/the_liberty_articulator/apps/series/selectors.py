from django.db.models import Count, Q

from .models import Series


def public_series():
    return (
        Series.objects.filter(is_active=True)
        .select_related("editor", "cover_image")
        .annotate(
            publication_count=Count(
                "publications",
                filter=Q(
                    publications__live=True,
                    publications__editorial_status="published",
                ),
            )
        )
        .order_by("sort_order", "title")
    )
