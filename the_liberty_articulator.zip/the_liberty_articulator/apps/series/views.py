from django.core.paginator import Paginator
from django.shortcuts import get_object_or_404, render

from apps.publications.selectors import public_publications

from .models import Series
from .selectors import public_series


def series_index(request):
    return render(request, "series/series_index.html", {"series_list": public_series()})


def series_detail(request, slug):
    series = get_object_or_404(
        Series.objects.select_related("editor", "cover_image"),
        slug=slug,
        is_active=True,
    )
    publications = public_publications().filter(series=series)
    page = Paginator(publications, 20).get_page(request.GET.get("page"))
    return render(
        request,
        "series/series_detail.html",
        {"series": series, "page_obj": page, "publications": page.object_list},
    )
