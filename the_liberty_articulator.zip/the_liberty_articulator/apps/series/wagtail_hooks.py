from wagtail import hooks
from wagtail.snippets.views.snippets import SnippetViewSet

from .models import Series


class SeriesViewSet(SnippetViewSet):
    model = Series
    icon = "folder-open-inverse"
    menu_label = "Series"
    list_display = ("title", "editor", "start_year", "end_year", "is_active")
    list_filter = ("is_active", "start_year")
    search_fields = ("title", "tagline")


@hooks.register("register_admin_viewset")
def register_series_viewset():
    return SeriesViewSet(name="series")
