from django.urls import path

from . import views

app_name = "series"

urlpatterns = [
    path("", views.series_index, name="index"),
    path("<slug:slug>/", views.series_detail, name="detail"),
]
