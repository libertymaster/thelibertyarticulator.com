from __future__ import annotations

from typing import ClassVar

from django.core.exceptions import ValidationError
from django.db import models
from django.urls import reverse
from django.utils.text import slugify
from wagtail.admin.panels import FieldPanel, MultiFieldPanel
from wagtail.fields import RichTextField
from wagtail.search import index

from apps.core.models import AuditableModel


class Series(index.Indexed, AuditableModel):
    title = models.CharField(max_length=220)
    slug = models.SlugField(max_length=240, unique=True, blank=True)
    tagline = models.CharField(max_length=300, blank=True)
    description = RichTextField(blank=True)
    editor = models.ForeignKey(
        "people.Person",
        blank=True,
        null=True,
        on_delete=models.SET_NULL,
        related_name="edited_series",
    )
    cover_image = models.ForeignKey(
        "wagtailimages.Image",
        blank=True,
        null=True,
        on_delete=models.SET_NULL,
        related_name="+",
    )
    start_year = models.PositiveSmallIntegerField(blank=True, null=True)
    end_year = models.PositiveSmallIntegerField(blank=True, null=True)
    sort_order = models.PositiveIntegerField(default=0)
    is_active = models.BooleanField(default=True, db_index=True)

    panels: ClassVar[list] = [
        FieldPanel("title"),
        FieldPanel("slug"),
        FieldPanel("tagline"),
        FieldPanel("description"),
        FieldPanel("editor"),
        FieldPanel("cover_image"),
        MultiFieldPanel([FieldPanel("start_year"), FieldPanel("end_year")], heading="Run"),
        FieldPanel("sort_order"),
        FieldPanel("is_active"),
    ]
    search_fields: ClassVar[list] = [
        index.SearchField("title", partial_match=True, boost=3),
        index.SearchField("tagline", partial_match=True, boost=2),
        index.SearchField("description"),
        index.FilterField("is_active"),
    ]

    class Meta:
        ordering = ("sort_order", "title")
        verbose_name_plural = "series"

    def __str__(self) -> str:
        return self.title

    @property
    def subtitle(self) -> str:
        return self.tagline

    def clean(self) -> None:
        super().clean()
        if self.start_year and self.end_year and self.end_year < self.start_year:
            raise ValidationError({"end_year": "End year cannot be before start year."})

    def save(self, *args, **kwargs):
        if not self.slug:
            base = slugify(self.title)[:220] or "series"
            candidate = base
            counter = 2
            while type(self).objects.exclude(pk=self.pk).filter(slug=candidate).exists():
                suffix = f"-{counter}"
                candidate = f"{base[: 240 - len(suffix)]}{suffix}"
                counter += 1
            self.slug = candidate
        return super().save(*args, **kwargs)

    def get_absolute_url(self) -> str:
        return reverse("series:detail", kwargs={"slug": self.slug})
