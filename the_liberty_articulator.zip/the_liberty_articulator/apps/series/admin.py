from typing import ClassVar

from django.contrib import admin

from .models import Series


@admin.register(Series)
class SeriesAdmin(admin.ModelAdmin):
    list_display = ("title", "editor", "start_year", "end_year", "is_active")
    list_filter = ("is_active", "start_year")
    prepopulated_fields: ClassVar[dict[str, tuple[str, ...]]] = {"slug": ("title",)}
    search_fields = ("title", "tagline", "description")
