"""Publication series and collections."""
