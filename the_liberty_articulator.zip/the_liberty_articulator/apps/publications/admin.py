from django.contrib import admin

from .models import Version


@admin.register(Version)
class VersionAdmin(admin.ModelAdmin):
    list_display = (
        "publication",
        "number",
        "editorial_status",
        "is_current",
        "created_by",
        "created_at",
    )
    list_filter = ("editorial_status", "is_current", "created_at")
    search_fields = ("publication__title", "change_summary")
    readonly_fields = (
        "publication",
        "number",
        "editorial_status",
        "snapshot",
        "change_summary",
        "is_current",
        "created_by",
        "updated_by",
        "created_at",
        "updated_at",
    )

    def has_add_permission(self, request):
        return False

    def has_delete_permission(self, request, obj=None):
        return False
