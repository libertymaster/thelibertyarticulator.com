from django.urls import path

from . import views

app_name = "publications"

urlpatterns = [
    path("", views.publication_index, name="index"),
    path("<slug:slug>/", views.publication_detail, name="detail"),
]
