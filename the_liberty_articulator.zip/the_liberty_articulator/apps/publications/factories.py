"""Factory Boy factories, loaded only in development/test environments."""

try:
    import factory
except ImportError:  # pragma: no cover - production dependencies omit Factory Boy
    factory = None  # type: ignore[assignment]

if factory is not None:
    from wagtail.models import Page

    from .models import PublicationPage

    class PublicationPageFactory(factory.django.DjangoModelFactory):
        class Meta:
            model = PublicationPage
            django_get_or_create = ("slug",)

        title = factory.Sequence(lambda number: f"Publication {number}")
        slug = factory.Sequence(lambda number: f"publication-{number}")
        abstract = factory.Faker("paragraph")
        body = factory.Faker("paragraph")

        @classmethod
        def _create(cls, model_class, *args, **kwargs):
            parent = kwargs.pop("parent", None) or Page.get_first_root_node()
            instance = model_class(*args, **kwargs)
            parent.add_child(instance=instance)
            return instance
