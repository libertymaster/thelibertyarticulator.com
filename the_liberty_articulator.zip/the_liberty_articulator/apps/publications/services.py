from __future__ import annotations

import json

from django.core.exceptions import PermissionDenied, ValidationError
from django.db import transaction
from django.db.models import Max
from django.urls import reverse
from django.utils import timezone

from apps.core.utils import site_url
from apps.references.services import render_citation, source_to_csl_json

from .models import PublicationPage, Version

TRANSITIONS = {
    "draft": {"in_review"},
    "in_review": {"changes_requested", "approved"},
    "changes_requested": {"in_review"},
    "approved": {"changes_requested", "published"},
    "published": {"archived"},
    "archived": {"draft"},
}


def available_transitions(publication: PublicationPage) -> tuple[str, ...]:
    return tuple(sorted(TRANSITIONS.get(publication.editorial_status, set())))


def publication_snapshot(publication: PublicationPage) -> dict:
    """Build a JSON-safe, human-auditable snapshot of publication content."""

    return {
        "title": publication.title,
        "slug": publication.slug,
        "subtitle": publication.subtitle,
        "dek": publication.dek,
        "abstract": publication.abstract,
        "body": str(publication.body),
        "publication_type": publication.publication_type,
        "editorial_status": publication.editorial_status,
        "published_at": publication.published_at.isoformat() if publication.published_at else None,
        "embargo_until": (
            publication.embargo_until.isoformat() if publication.embargo_until else None
        ),
        "series": publication.series_id,
        "volume": publication.volume,
        "issue": publication.issue,
        "featured": publication.featured,
        "peer_reviewed": publication.peer_reviewed,
        "canonical_url": publication.canonical_url,
        "doi": publication.doi,
        "categories": list(publication.categories.values_list("slug", flat=True)),
        "keywords": list(publication.keywords.values_list("slug", flat=True)),
        "contributors": [
            {
                "person_id": contributor.person_id,
                "name": contributor.display_name,
                "role": contributor.role,
                "corresponding": contributor.corresponding,
            }
            for contributor in publication.contributors.select_related("person")
        ],
        "sources": [
            {
                "source_id": citation.source_id,
                "citation_key": citation.source.citation_key,
                "locator": citation.locator,
                "note": citation.note,
            }
            for citation in publication.citations.select_related("source")
        ],
    }


@transaction.atomic
def create_version(
    publication: PublicationPage,
    *,
    actor=None,
    change_summary: str = "",
) -> Version:
    locked = PublicationPage.objects.select_for_update().get(pk=publication.pk)
    Version.objects.filter(publication=locked, is_current=True).update(is_current=False)
    latest = Version.objects.filter(publication=locked).aggregate(latest=Max("number"))
    number = (latest["latest"] or 0) + 1
    actor = actor if getattr(actor, "is_authenticated", False) else None
    return Version.objects.create(
        publication=locked,
        number=number,
        editorial_status=locked.editorial_status,
        snapshot=publication_snapshot(locked),
        change_summary=change_summary.strip(),
        is_current=True,
        created_by=actor,
        updated_by=actor,
    )


def _check_transition_permission(publication: PublicationPage, target: str, actor) -> None:
    if actor is None or not getattr(actor, "is_authenticated", False):
        return
    permissions = publication.permissions_for_user(actor)
    if target == PublicationPage.EditorialStatus.PUBLISHED:
        allowed = permissions.can_publish()
    else:
        allowed = permissions.can_edit()
    if not allowed:
        raise PermissionDenied("You do not have permission for this editorial transition.")


@transaction.atomic
def transition_publication(
    publication: PublicationPage,
    target: str,
    *,
    actor=None,
    note: str = "",
    publish_revision: bool = True,
) -> PublicationPage:
    """Apply and record a validated editorial state transition."""

    locked = PublicationPage.objects.select_for_update().get(pk=publication.pk)
    target = str(target)
    labels = dict(PublicationPage.EditorialStatus.choices)
    if target not in labels:
        raise ValidationError({"editorial_status": "Unknown editorial status."})
    if target not in TRANSITIONS.get(locked.editorial_status, set()):
        raise ValidationError(
            {
                "editorial_status": (
                    f"Cannot transition from {locked.get_editorial_status_display()} "
                    f"to {labels[target]}."
                )
            }
        )
    _check_transition_permission(locked, target, actor)
    previous = locked.editorial_status
    locked.editorial_status = target
    if target == PublicationPage.EditorialStatus.PUBLISHED and not locked.published_at:
        locked.published_at = timezone.now()
    locked.save(update_fields=("editorial_status", "published_at"))

    revision_user = actor if getattr(actor, "is_authenticated", False) else None
    revision = locked.save_revision(user=revision_user, log_action=True)
    if target == PublicationPage.EditorialStatus.PUBLISHED and publish_revision:
        revision.publish(user=actor if getattr(actor, "is_authenticated", False) else None)
        locked.refresh_from_db()
    elif target == PublicationPage.EditorialStatus.ARCHIVED and locked.live:
        locked.unpublish(user=revision_user, log_action=True)
        locked.refresh_from_db()

    create_version(locked, actor=actor, change_summary=note or f"{previous} → {target}")

    from .tasks import notify_editorial_transition

    transaction.on_commit(lambda: notify_editorial_transition.delay(locked.pk, previous, target))
    return locked


def submit_for_review(
    publication: PublicationPage, *, actor=None, note: str = ""
) -> PublicationPage:
    return transition_publication(
        publication,
        "in_review",
        actor=actor,
        note=note,
    )


def request_changes(publication: PublicationPage, *, actor=None, note: str = "") -> PublicationPage:
    return transition_publication(
        publication,
        "changes_requested",
        actor=actor,
        note=note,
    )


def approve(publication: PublicationPage, *, actor=None, note: str = "") -> PublicationPage:
    return transition_publication(
        publication,
        "approved",
        actor=actor,
        note=note,
    )


def publish(publication: PublicationPage, *, actor=None, note: str = "") -> PublicationPage:
    return transition_publication(
        publication,
        "published",
        actor=actor,
        note=note,
    )


def render_publication_citations(publication: PublicationPage, style: str = "apa") -> list[str]:
    citations: list[str] = []
    for relation in publication.citations.select_related("source"):
        rendered = render_citation(relation.source, style=style)
        if relation.locator:
            rendered = f"{rendered} ({relation.locator})"
        citations.append(rendered)
    return citations


def publication_schema(publication: PublicationPage, *, request=None) -> dict:
    canonical = publication.canonical_url
    if not canonical:
        relative = publication.url or reverse(
            "publications:detail", kwargs={"slug": publication.slug}
        )
        canonical = request.build_absolute_uri(relative) if request else site_url(relative)
    contributors = publication.contributors.select_related("person")
    authors = [
        {
            "@type": "Person",
            "name": contributor.display_name,
            **({"sameAs": contributor.person.orcid_url} if contributor.person.orcid_url else {}),
            **(
                {"url": site_url(contributor.person.get_absolute_url())}
                if contributor.person.slug
                else {}
            ),
        }
        for contributor in contributors
        if contributor.role == contributor.Role.AUTHOR
    ]
    schema = {
        "@context": "https://schema.org",
        "@type": "ScholarlyArticle" if publication.peer_reviewed else "Article",
        "@id": canonical,
        "url": canonical,
        "headline": publication.title,
        "alternativeHeadline": publication.subtitle or publication.dek,
        "description": publication.abstract or publication.dek,
        "articleBody": str(publication.body),
        "articleSection": list(publication.categories.values_list("name", flat=True)),
        "keywords": list(publication.keywords.values_list("name", flat=True)),
        "author": authors,
        "datePublished": publication.published_at.isoformat() if publication.published_at else None,
        "dateModified": (
            publication.last_published_at.isoformat() if publication.last_published_at else None
        ),
        "isAccessibleForFree": True,
        "citation": [
            source_to_csl_json(relation.source)
            for relation in publication.citations.select_related("source")
        ],
        "sameAs": f"https://doi.org/{publication.doi}" if publication.doi else None,
        "isPartOf": (
            {
                "@type": "CreativeWorkSeries",
                "name": publication.series.title,
                "url": site_url(publication.series.get_absolute_url()),
            }
            if publication.series
            else None
        ),
        "image": publication.hero_image.file.url if publication.hero_image else None,
    }
    return {key: value for key, value in schema.items() if value not in (None, "", [])}


def publication_schema_json(publication: PublicationPage, *, request=None) -> str:
    serialized = json.dumps(
        publication_schema(publication, request=request),
        ensure_ascii=False,
        separators=(",", ":"),
    )
    # This JSON is embedded in a script element. Escape HTML delimiters and JS line
    # separators so user-authored text cannot terminate the element or alter parsing.
    return (
        serialized.replace("&", "\\u0026")
        .replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("\u2028", "\\u2028")
        .replace("\u2029", "\\u2029")
    )
