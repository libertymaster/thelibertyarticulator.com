from __future__ import annotations

from django.db.models import Q, QuerySet
from django.utils import timezone

from .models import PublicationPage


def public_publications(*, at=None) -> QuerySet[PublicationPage]:
    """Return pages visible now, including publish and embargo scheduling rules."""

    at = at or timezone.now()
    return (
        PublicationPage.objects.live()
        .public()
        .filter(editorial_status=PublicationPage.EditorialStatus.PUBLISHED)
        .filter(Q(published_at__isnull=True) | Q(published_at__lte=at))
        .filter(Q(embargo_until__isnull=True) | Q(embargo_until__lte=at))
        .select_related("hero_image", "series")
        .prefetch_related("categories", "keywords", "contributors__person")
        .order_by("-published_at", "-first_published_at", "title")
    )


def filtered_publications(
    *,
    query: str = "",
    category: str = "",
    keyword: str = "",
    series: str = "",
    publication_type: str = "",
) -> QuerySet[PublicationPage]:
    publications = public_publications()
    if query:
        publications = publications.filter(
            Q(title__icontains=query)
            | Q(subtitle__icontains=query)
            | Q(dek__icontains=query)
            | Q(abstract__icontains=query)
            | Q(body__icontains=query)
        )
    if category:
        publications = publications.filter(categories__slug=category, categories__is_active=True)
    if keyword:
        publications = publications.filter(keywords__slug=keyword, keywords__is_active=True)
    if series:
        publications = publications.filter(series__slug=series, series__is_active=True)
    if publication_type:
        publications = publications.filter(publication_type=publication_type)
    return publications.distinct()


def featured_publications(*, limit: int = 6) -> QuerySet[PublicationPage]:
    return public_publications().filter(featured=True)[:limit]


def publications_by_person(person) -> QuerySet[PublicationPage]:
    return public_publications().filter(contributors__person=person).distinct()
