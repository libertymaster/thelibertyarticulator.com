from __future__ import annotations

import logging

from django.conf import settings
from django.core import mail
from django.core.management import call_command

logger = logging.getLogger(__name__)

try:
    from celery import shared_task
except ImportError:  # Keep web/import tooling usable without the optional worker extra.

    def shared_task(*decorator_args, **decorator_kwargs):
        def decorate(function):
            function.delay = function
            return function

        if len(decorator_args) == 1 and callable(decorator_args[0]) and not decorator_kwargs:
            return decorate(decorator_args[0])
        return decorate


def _editor_recipients() -> list[str]:
    return [value for value in getattr(settings, "PUBLICATION_EDITOR_EMAILS", []) if value]


@shared_task(autoretry_for=(OSError,), retry_backoff=True, max_retries=4)
def notify_editorial_transition(publication_id: int, previous: str, current: str) -> int:
    from .models import PublicationPage

    try:
        publication = PublicationPage.objects.get(pk=publication_id)
    except PublicationPage.DoesNotExist:
        logger.info("Skipping transition notification for deleted publication %s", publication_id)
        return 0
    recipients = _editor_recipients()
    if not recipients:
        return 0
    return mail.send_mail(
        subject=f"Editorial status: {publication.title}",
        message=f"“{publication.title}” moved from {previous} to {current}.",
        from_email=getattr(settings, "DEFAULT_FROM_EMAIL", None),
        recipient_list=recipients,
        fail_silently=False,
    )


@shared_task(autoretry_for=(OSError,), retry_backoff=True, max_retries=4)
def notify_publication_published(publication_id: int) -> int:
    from .models import PublicationPage

    try:
        publication = PublicationPage.objects.prefetch_related("contributors__person").get(
            pk=publication_id
        )
    except PublicationPage.DoesNotExist:
        return 0
    recipients = {
        contribution.person.email
        for contribution in publication.contributors.all()
        if contribution.person.email
    }
    recipients.update(_editor_recipients())
    if not recipients:
        return 0
    return mail.send_mail(
        subject=f"Published: {publication.title}",
        message=(
            f"“{publication.title}” is now published at "
            f"{publication.full_url or publication.url or 'the site'}."
        ),
        from_email=getattr(settings, "DEFAULT_FROM_EMAIL", None),
        recipient_list=sorted(recipients),
        fail_silently=False,
    )


@shared_task
def rebuild_publication_index(backend_name: str | None = None) -> str:
    options = {"backend_name": backend_name} if backend_name else {}
    call_command("update_index", **options)
    return backend_name or "default"
