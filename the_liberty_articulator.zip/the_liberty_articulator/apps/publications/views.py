from django.core.paginator import Paginator
from django.http import Http404
from django.shortcuts import render

from apps.series.models import Series
from apps.taxonomy.models import Category, Keyword

from .models import PublicationPage
from .selectors import featured_publications, filtered_publications, public_publications
from .services import publication_schema_json, render_publication_citations


def home(request):
    featured = featured_publications(limit=6)
    return render(
        request,
        "home.html",
        {"featured_publications": featured, "recent_publications": public_publications()[:6]},
    )


def publication_index(request):
    filters = {
        "query": request.GET.get("q", "").strip(),
        "category": request.GET.get("category", "").strip(),
        "keyword": request.GET.get("keyword", "").strip(),
        "series": request.GET.get("series", "").strip(),
        "publication_type": request.GET.get("type", "").strip(),
    }
    paginator = Paginator(filtered_publications(**filters), 12)
    page = paginator.get_page(request.GET.get("page"))
    return render(
        request,
        "publications/publication_index.html",
        {
            "page_obj": page,
            "publications": page.object_list,
            "query": filters["query"],
            "filters": filters,
            "categories": Category.objects.filter(is_active=True, parent__isnull=True),
            "keywords": Keyword.objects.filter(is_active=True),
            "series_list": Series.objects.filter(is_active=True),
            "publication_types": PublicationPage.Type.choices,
        },
    )


def publication_detail(request, slug):
    publication = filtered_publications().filter(slug=slug).first()
    if publication is None:
        raise Http404("Publication not found")
    return render(
        request,
        "publications/publication_detail.html",
        {
            "page": publication,
            "publication": publication,
            "schema_json": publication_schema_json(publication, request=request),
            "rendered_citations": render_publication_citations(publication),
        },
    )
