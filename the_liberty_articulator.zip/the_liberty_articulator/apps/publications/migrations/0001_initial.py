import django.db.models.deletion
import modelcluster.fields
import wagtail.fields
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("people", "0001_initial"),
        ("references", "0001_initial"),
        ("series", "0001_initial"),
        ("taxonomy", "0001_initial"),
        ("wagtailcore", "0001_initial"),
        ("wagtailimages", "0001_initial"),
    ]

    operations = [
        migrations.CreateModel(
            name="PublicationPage",
            fields=[
                ("page_ptr", models.OneToOneField(auto_created=True, on_delete=django.db.models.deletion.CASCADE, parent_link=True, primary_key=True, serialize=False, to="wagtailcore.page")),
                ("subtitle", models.CharField(blank=True, max_length=300)),
                ("dek", models.CharField(blank=True, help_text="Short display summary for cards and social previews.", max_length=500)),
                ("abstract", models.TextField(blank=True)),
                ("body", wagtail.fields.RichTextField(blank=True, features=["h2", "h3", "h4", "bold", "italic", "ol", "ul", "hr", "link", "document-link", "image", "embed", "blockquote"])),
                ("publication_type", models.CharField(choices=[("article", "Article"), ("essay", "Essay"), ("analysis", "Analysis"), ("review", "Review"), ("interview", "Interview"), ("primary_source", "Primary source")], db_index=True, default="article", max_length=30)),
                ("editorial_status", models.CharField(choices=[("draft", "Draft"), ("in_review", "In review"), ("changes_requested", "Changes requested"), ("approved", "Approved"), ("published", "Published"), ("archived", "Archived")], db_index=True, default="draft", max_length=30)),
                ("published_at", models.DateTimeField(blank=True, db_index=True, null=True)),
                ("embargo_until", models.DateTimeField(blank=True, db_index=True, null=True)),
                ("featured", models.BooleanField(db_index=True, default=False)),
                ("peer_reviewed", models.BooleanField(default=False)),
                ("canonical_url", models.URLField(blank=True, max_length=1000)),
                ("doi", models.CharField(blank=True, help_text="Optional publication DOI.", max_length=300)),
                ("volume", models.CharField(blank=True, max_length=40)),
                ("issue", models.CharField(blank=True, max_length=40)),
                ("categories", modelcluster.fields.ParentalManyToManyField(blank=True, related_name="publications", to="taxonomy.category")),
                ("hero_image", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="+", to="wagtailimages.image")),
                ("keywords", modelcluster.fields.ParentalManyToManyField(blank=True, related_name="publications", to="taxonomy.keyword")),
                ("series", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="publications", to="series.series")),
            ],
            options={
                "ordering": ("-published_at", "-first_published_at", "title"),
                "indexes": [
                    models.Index(fields=["editorial_status", "published_at"], name="publication_state_date_idx"),
                    models.Index(fields=["featured", "published_at"], name="publication_featured_idx"),
                ],
            },
            bases=("wagtailcore.page",),
        ),
        migrations.CreateModel(
            name="Contributor",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("sort_order", models.IntegerField(blank=True, editable=False, null=True)),
                ("role", models.CharField(choices=[("author", "Author"), ("editor", "Editor"), ("translator", "Translator"), ("researcher", "Researcher"), ("illustrator", "Illustrator"), ("reviewer", "Reviewer")], default="author", max_length=30)),
                ("credit_name", models.CharField(blank=True, help_text="Optional publication-specific byline name.", max_length=200)),
                ("corresponding", models.BooleanField(default=False)),
                ("person", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="publication_contributions", to="people.person")),
                ("publication", modelcluster.fields.ParentalKey(on_delete=django.db.models.deletion.CASCADE, related_name="contributors", to="publications.publicationpage")),
            ],
            options={"ordering": ["sort_order"]},
        ),
        migrations.CreateModel(
            name="PublicationSource",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("sort_order", models.IntegerField(blank=True, editable=False, null=True)),
                ("locator", models.CharField(blank=True, help_text="Page, chapter, section, timestamp, or archival locator.", max_length=120)),
                ("note", models.TextField(blank=True)),
                ("quotation", models.TextField(blank=True)),
                ("publication", modelcluster.fields.ParentalKey(on_delete=django.db.models.deletion.CASCADE, related_name="citations", to="publications.publicationpage")),
                ("source", models.ForeignKey(on_delete=django.db.models.deletion.PROTECT, related_name="publication_citations", to="references.source")),
            ],
            options={"ordering": ["sort_order"]},
        ),
        migrations.CreateModel(
            name="Version",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True, db_index=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("number", models.PositiveIntegerField()),
                ("editorial_status", models.CharField(choices=[("draft", "Draft"), ("in_review", "In review"), ("changes_requested", "Changes requested"), ("approved", "Approved"), ("published", "Published"), ("archived", "Archived")], max_length=30)),
                ("snapshot", models.JSONField(default=dict)),
                ("change_summary", models.CharField(blank=True, max_length=500)),
                ("is_current", models.BooleanField(db_index=True, default=True)),
                ("created_by", models.ForeignKey(blank=True, editable=False, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="publications_version_created", to=settings.AUTH_USER_MODEL)),
                ("publication", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="domain_versions", to="publications.publicationpage")),
                ("updated_by", models.ForeignKey(blank=True, editable=False, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="publications_version_updated", to=settings.AUTH_USER_MODEL)),
            ],
            options={"ordering": ("publication", "-number")},
        ),
        migrations.AddConstraint(
            model_name="contributor",
            constraint=models.UniqueConstraint(fields=("publication", "person", "role"), name="unique_publication_person_role"),
        ),
        migrations.AddConstraint(
            model_name="publicationsource",
            constraint=models.UniqueConstraint(fields=("publication", "source", "locator"), name="unique_publication_source_locator"),
        ),
        migrations.AddConstraint(
            model_name="version",
            constraint=models.UniqueConstraint(fields=("publication", "number"), name="unique_publication_version_number"),
        ),
        migrations.AddConstraint(
            model_name="version",
            constraint=models.UniqueConstraint(condition=models.Q(("is_current", True)), fields=("publication",), name="one_current_publication_version"),
        ),
    ]
