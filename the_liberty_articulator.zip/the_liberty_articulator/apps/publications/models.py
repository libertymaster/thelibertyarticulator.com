from __future__ import annotations

from typing import ClassVar

from django.core.exceptions import ValidationError
from django.db import models
from django.urls import reverse
from django.utils import timezone
from modelcluster.fields import ParentalKey, ParentalManyToManyField
from wagtail.admin.panels import FieldPanel, InlinePanel, MultiFieldPanel
from wagtail.fields import RichTextField
from wagtail.models import Orderable, Page
from wagtail.search import index

from apps.core.models import AuditableModel
from apps.references.models import Source


class PublicationPage(Page):
    class Type(models.TextChoices):
        ARTICLE = "article", "Article"
        ESSAY = "essay", "Essay"
        ANALYSIS = "analysis", "Analysis"
        REVIEW = "review", "Review"
        INTERVIEW = "interview", "Interview"
        PRIMARY_SOURCE = "primary_source", "Primary source"

    class EditorialStatus(models.TextChoices):
        DRAFT = "draft", "Draft"
        IN_REVIEW = "in_review", "In review"
        CHANGES_REQUESTED = "changes_requested", "Changes requested"
        APPROVED = "approved", "Approved"
        PUBLISHED = "published", "Published"
        ARCHIVED = "archived", "Archived"

    subtitle = models.CharField(max_length=300, blank=True)
    dek = models.CharField(
        max_length=500,
        blank=True,
        help_text="Short display summary for cards and social previews.",
    )
    abstract = models.TextField(blank=True)
    body = RichTextField(
        blank=True,
        features=[
            "h2",
            "h3",
            "h4",
            "bold",
            "italic",
            "ol",
            "ul",
            "hr",
            "link",
            "document-link",
            "image",
            "embed",
            "blockquote",
        ],
    )
    publication_type = models.CharField(
        max_length=30, choices=Type.choices, default=Type.ARTICLE, db_index=True
    )
    editorial_status = models.CharField(
        max_length=30,
        choices=EditorialStatus.choices,
        default=EditorialStatus.DRAFT,
        db_index=True,
    )
    published_at = models.DateTimeField(blank=True, null=True, db_index=True)
    embargo_until = models.DateTimeField(blank=True, null=True, db_index=True)
    featured = models.BooleanField(default=False, db_index=True)
    peer_reviewed = models.BooleanField(default=False)
    canonical_url = models.URLField(max_length=1000, blank=True)
    doi = models.CharField(max_length=300, blank=True, help_text="Optional publication DOI.")
    hero_image = models.ForeignKey(
        "wagtailimages.Image",
        blank=True,
        null=True,
        on_delete=models.SET_NULL,
        related_name="+",
    )
    series = models.ForeignKey(
        "series.Series",
        blank=True,
        null=True,
        on_delete=models.SET_NULL,
        related_name="publications",
    )
    volume = models.CharField(max_length=40, blank=True)
    issue = models.CharField(max_length=40, blank=True)
    categories = ParentalManyToManyField(
        "taxonomy.Category", blank=True, related_name="publications"
    )
    keywords = ParentalManyToManyField("taxonomy.Keyword", blank=True, related_name="publications")

    content_panels: ClassVar[list] = [
        *Page.content_panels,
        MultiFieldPanel(
            [FieldPanel("subtitle"), FieldPanel("dek"), FieldPanel("abstract")],
            heading="Summary",
        ),
        FieldPanel("body"),
        InlinePanel("contributors", label="Contributor", min_num=1),
        InlinePanel("citations", label="Source"),
        MultiFieldPanel(
            [
                FieldPanel("publication_type"),
                FieldPanel("series"),
                FieldPanel("volume"),
                FieldPanel("issue"),
            ],
            heading="Publication details",
        ),
        MultiFieldPanel(
            [
                FieldPanel("editorial_status"),
                FieldPanel("published_at"),
                FieldPanel("embargo_until"),
            ],
            heading="Editorial state",
        ),
        MultiFieldPanel([FieldPanel("categories"), FieldPanel("keywords")], heading="Taxonomy"),
        MultiFieldPanel(
            [
                FieldPanel("hero_image"),
                FieldPanel("featured"),
                FieldPanel("peer_reviewed"),
                FieldPanel("doi"),
                FieldPanel("canonical_url"),
            ],
            heading="Presentation",
        ),
    ]
    search_fields: ClassVar[list] = [
        *Page.search_fields,
        index.SearchField("subtitle", partial_match=True, boost=2),
        index.SearchField("dek", partial_match=True, boost=2),
        index.SearchField("abstract", boost=2),
        index.SearchField("body"),
        index.FilterField("publication_type"),
        index.FilterField("editorial_status"),
        index.FilterField("published_at"),
        index.FilterField("embargo_until"),
        index.FilterField("featured"),
        index.RelatedFields("categories", [index.SearchField("name", partial_match=True)]),
        index.RelatedFields("keywords", [index.SearchField("name", partial_match=True)]),
        index.RelatedFields("contributors", [index.SearchField("credit_name", partial_match=True)]),
    ]

    subpage_types: ClassVar[list[str]] = []

    class Meta:
        ordering = ("-published_at", "-first_published_at", "title")
        indexes: ClassVar[list] = [
            models.Index(
                fields=("editorial_status", "published_at"),
                name="publication_state_date_idx",
            ),
            models.Index(fields=("featured", "published_at"), name="publication_featured_idx"),
        ]

    def __str__(self) -> str:
        return self.title

    def clean(self) -> None:
        super().clean()
        if self.embargo_until and self.published_at and self.embargo_until < self.published_at:
            raise ValidationError(
                {"embargo_until": "Embargo cannot end before the publication date."}
            )
        if self.editorial_status == self.EditorialStatus.PUBLISHED and not self.published_at:
            self.published_at = timezone.now()

    @property
    def is_publicly_available(self) -> bool:
        now = timezone.now()
        return bool(
            self.live
            and self.editorial_status == self.EditorialStatus.PUBLISHED
            and (not self.published_at or self.published_at <= now)
            and (not self.embargo_until or self.embargo_until <= now)
        )

    @property
    def byline(self) -> str:
        names = [contributor.display_name for contributor in self.contributors.all()]
        if not names:
            return ""
        if len(names) == 1:
            return names[0]
        return ", ".join(names[:-1]) + f" and {names[-1]}"

    @property
    def publication_date(self):
        return self.published_at or self.first_published_at

    @property
    def updated_date(self):
        return self.last_published_at

    @property
    def reading_time(self) -> int:
        from django.utils.html import strip_tags

        word_count = len(strip_tags(str(self.body)).split())
        return max(1, round(word_count / 220)) if word_count else 0

    @property
    def sources(self):
        """Compatibility name used by publication templates."""

        return self.citations

    @property
    def schema_json_ld(self) -> str:
        from .services import publication_schema_json

        return publication_schema_json(self)

    def get_absolute_url(self) -> str:
        return self.url or reverse("publications:detail", kwargs={"slug": self.slug})

    def get_context(self, request, *args, **kwargs):
        context = super().get_context(request, *args, **kwargs)
        from .services import publication_schema_json

        context["publication"] = self
        context["schema_json"] = publication_schema_json(self, request=request)
        context["rendered_citations"] = [
            citation.rendered for citation in self.citations.select_related("source")
        ]
        return context


class Contributor(Orderable):
    class Role(models.TextChoices):
        AUTHOR = "author", "Author"
        EDITOR = "editor", "Editor"
        TRANSLATOR = "translator", "Translator"
        RESEARCHER = "researcher", "Researcher"
        ILLUSTRATOR = "illustrator", "Illustrator"
        REVIEWER = "reviewer", "Reviewer"

    publication = ParentalKey(
        PublicationPage, on_delete=models.CASCADE, related_name="contributors"
    )
    person = models.ForeignKey(
        "people.Person",
        on_delete=models.PROTECT,
        related_name="publication_contributions",
    )
    role = models.CharField(max_length=30, choices=Role.choices, default=Role.AUTHOR)
    credit_name = models.CharField(
        max_length=200,
        blank=True,
        help_text="Optional publication-specific byline name.",
    )
    corresponding = models.BooleanField(default=False)

    panels: ClassVar[list] = [
        FieldPanel("person"),
        FieldPanel("role"),
        FieldPanel("credit_name"),
        FieldPanel("corresponding"),
    ]

    class Meta(Orderable.Meta):
        constraints: ClassVar[list] = [
            models.UniqueConstraint(
                fields=("publication", "person", "role"),
                name="unique_publication_person_role",
            ),
        ]

    def __str__(self) -> str:
        return f"{self.display_name} — {self.get_role_display()}"

    @property
    def display_name(self) -> str:
        return self.credit_name or self.person.name


class PublicationSource(Orderable):
    publication = ParentalKey(PublicationPage, on_delete=models.CASCADE, related_name="citations")
    source = models.ForeignKey(
        Source, on_delete=models.PROTECT, related_name="publication_citations"
    )
    locator = models.CharField(
        max_length=120,
        blank=True,
        help_text="Page, chapter, section, timestamp, or archival locator.",
    )
    note = models.TextField(blank=True)
    quotation = models.TextField(blank=True)

    panels: ClassVar[list] = [
        FieldPanel("source"),
        FieldPanel("locator"),
        FieldPanel("note"),
        FieldPanel("quotation"),
    ]

    class Meta(Orderable.Meta):
        constraints: ClassVar[list] = [
            models.UniqueConstraint(
                fields=("publication", "source", "locator"),
                name="unique_publication_source_locator",
            ),
        ]

    def __str__(self) -> str:
        return f"{self.publication}: {self.source}"

    @property
    def rendered(self) -> str:
        from apps.references.services import render_citation

        citation = render_citation(self.source)
        return f"{citation} ({self.locator})" if self.locator else citation


class Version(AuditableModel):
    """Immutable domain snapshot at an editorial milestone."""

    publication = models.ForeignKey(
        PublicationPage, on_delete=models.CASCADE, related_name="domain_versions"
    )
    number = models.PositiveIntegerField()
    editorial_status = models.CharField(
        max_length=30, choices=PublicationPage.EditorialStatus.choices
    )
    snapshot = models.JSONField(default=dict)
    change_summary = models.CharField(max_length=500, blank=True)
    is_current = models.BooleanField(default=True, db_index=True)

    class Meta:
        ordering = ("publication", "-number")
        constraints: ClassVar[list] = [
            models.UniqueConstraint(
                fields=("publication", "number"),
                name="unique_publication_version_number",
            ),
            models.UniqueConstraint(
                fields=("publication",),
                condition=models.Q(is_current=True),
                name="one_current_publication_version",
            ),
        ]

    def __str__(self) -> str:
        return f"{self.publication.title} v{self.number}"

    def save(self, *args, **kwargs):
        if self.pk and type(self).objects.filter(pk=self.pk).exists():
            previous = (
                type(self).objects.only("snapshot", "publication_id", "number").get(pk=self.pk)
            )
            changed = (
                previous.snapshot != self.snapshot
                or previous.publication_id != self.publication_id
                or previous.number != self.number
            )
            if changed:
                raise ValidationError("Publication version snapshots are immutable.")
        return super().save(*args, **kwargs)


PublicationVersion = Version
PublicationContributor = Contributor

__all__ = [
    "Contributor",
    "PublicationContributor",
    "PublicationPage",
    "PublicationSource",
    "PublicationVersion",
    "Source",
    "Version",
]
