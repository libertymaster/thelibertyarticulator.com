from django.templatetags.static import static
from django.utils import timezone
from django.utils.html import format_html
from wagtail import hooks
from wagtail.admin.viewsets.pages import PageListingViewSet

from .models import PublicationPage
from .services import create_version
from .tasks import notify_publication_published


class PublicationPageListingViewSet(PageListingViewSet):
    name = "publication_pages"
    model = PublicationPage
    icon = "doc-full-inverse"
    menu_label = "Publications"
    add_to_admin_menu = True


publication_page_listing = PublicationPageListingViewSet()


@hooks.register("register_admin_viewset")
def register_publication_listing():
    return publication_page_listing


@hooks.register("insert_editor_js")
def publication_editor_js():
    return format_html('<script src="{}"></script>', static("js/admin-custom.js"))


@hooks.register("after_publish_page")
def record_publication_publish(request, page):
    publication = page.specific
    if not isinstance(publication, PublicationPage):
        return None
    needs_state_sync = (
        publication.editorial_status != PublicationPage.EditorialStatus.PUBLISHED
        or not publication.published_at
    )
    if needs_state_sync:
        published_at = publication.published_at or timezone.now()
        PublicationPage.objects.filter(pk=publication.pk).update(
            editorial_status=PublicationPage.EditorialStatus.PUBLISHED,
            published_at=published_at,
        )
        publication.editorial_status = PublicationPage.EditorialStatus.PUBLISHED
        publication.published_at = published_at
    create_version(publication, actor=request.user, change_summary="Published through Wagtail")
    notify_publication_published.delay(publication.pk)
    return None


@hooks.register("after_unpublish_page")
def record_publication_unpublish(request, page):
    publication = page.specific
    if isinstance(publication, PublicationPage):
        PublicationPage.objects.filter(pk=publication.pk).update(
            editorial_status=PublicationPage.EditorialStatus.ARCHIVED
        )
        publication.editorial_status = PublicationPage.EditorialStatus.ARCHIVED
        create_version(
            publication,
            actor=request.user,
            change_summary="Unpublished through Wagtail",
        )
    return None
