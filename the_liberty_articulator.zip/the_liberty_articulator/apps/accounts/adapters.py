from __future__ import annotations

import hashlib

from django.conf import settings
from django.contrib.auth import get_user_model
from django.core.exceptions import ImproperlyConfigured
from django.db import transaction


class FusionAuthOIDCAdapter:
    """Map verified FusionAuth userinfo claims onto the configured user model."""

    @staticmethod
    def _subject_username(subject: str) -> str:
        return f"fusionauth_{hashlib.sha256(subject.encode('utf-8')).hexdigest()[:32]}"

    @transaction.atomic
    def get_or_create_user(self, claims: dict):
        subject = str(claims.get("sub", "")).strip()
        if not subject:
            raise ValueError("FusionAuth userinfo did not contain a subject claim.")
        user_model = get_user_model()
        field_names = {field.name for field in user_model._meta.get_fields()}
        email = str(claims.get("email", "")).strip().lower()

        subject_field = getattr(settings, "FUSIONAUTH_SUBJECT_FIELD", "fusionauth_subject")
        if subject_field in field_names:
            lookup = {subject_field: subject}
        elif user_model.USERNAME_FIELD == "username" and "username" in field_names:
            lookup = {"username": self._subject_username(subject)}
        elif user_model.USERNAME_FIELD == "email" and email and claims.get("email_verified"):
            lookup = {"email": email}
        else:
            raise ImproperlyConfigured(
                "The user model must expose a FusionAuth subject field, a username field, "
                "or use verified email as USERNAME_FIELD."
            )

        user, created = user_model._default_manager.select_for_update().get_or_create(**lookup)
        changed: list[str] = []
        values = {
            "email": email,
            "first_name": str(claims.get("given_name", "")).strip(),
            "last_name": str(claims.get("family_name", "")).strip(),
        }
        for field, value in values.items():
            if field in field_names and value and getattr(user, field) != value:
                setattr(user, field, value)
                changed.append(field)
        if subject_field in field_names and getattr(user, subject_field) != subject:
            setattr(user, subject_field, subject)
            changed.append(subject_field)
        if created and hasattr(user, "set_unusable_password"):
            user.set_unusable_password()
            changed.append("password")
        if hasattr(user, "is_active") and not user.is_active:
            user.is_active = True
            changed.append("is_active")

        admin_roles = set(getattr(settings, "FUSIONAUTH_ADMIN_ROLES", ()))
        roles = set(claims.get("roles") or claims.get("application_roles") or ())
        if "is_staff" in field_names and admin_roles and not getattr(user, "is_superuser", False):
            desired = bool(admin_roles & roles)
            if user.is_staff != desired:
                user.is_staff = desired
                changed.append("is_staff")
        if changed:
            user.save(update_fields=sorted(set(changed)))
        return user


try:
    from mozilla_django_oidc.auth import OIDCAuthenticationBackend
except ImportError:
    OIDCAuthenticationBackend = None


if OIDCAuthenticationBackend is not None:

    class FusionAuthAuthenticationBackend(OIDCAuthenticationBackend):
        """Compatibility backend for deployments that opt into mozilla-django-oidc."""

        adapter_class = FusionAuthOIDCAdapter

        def create_user(self, claims):
            return self.adapter_class().get_or_create_user(claims)

        def update_user(self, user, claims):
            return self.adapter_class().get_or_create_user(claims)
else:
    FusionAuthAuthenticationBackend = None  # type: ignore[misc, assignment]
