from django.urls import path

from . import views

app_name = "accounts"

urlpatterns = [
    path("login/", views.oidc_login, name="login"),
    path("callback/", views.oidc_callback, name="callback"),
    path("logout/", views.oidc_logout, name="logout"),
    path("status/", views.auth_status, name="status"),
]
