from __future__ import annotations

import base64
import hashlib
import secrets
from urllib.parse import urlencode

import httpx
from django.conf import settings
from django.contrib.auth import login, logout
from django.http import HttpResponse, JsonResponse
from django.shortcuts import redirect
from django.urls import reverse
from django.utils.http import url_has_allowed_host_and_scheme
from django.views.decorators.http import require_GET, require_http_methods

from .adapters import FusionAuthOIDCAdapter

SESSION_STATE = "fusionauth_oidc_state"
SESSION_VERIFIER = "fusionauth_oidc_verifier"
SESSION_NEXT = "fusionauth_oidc_next"


def _setting(name: str, default: str = "") -> str:
    return str(getattr(settings, name, default)).rstrip("/")


def _issuer() -> str:
    return _setting("FUSIONAUTH_ISSUER", "https://auth.thelibertyarticulator.com")


def _endpoint(setting_name: str, path: str) -> str:
    return _setting(setting_name) or f"{_issuer()}{path}"


def _safe_next(request, value: str | None, default: str = "/") -> str:
    if value and url_has_allowed_host_and_scheme(
        value, allowed_hosts={request.get_host()}, require_https=request.is_secure()
    ):
        return value
    return default


@require_GET
def oidc_login(request):
    client_id = _setting("FUSIONAUTH_CLIENT_ID")
    if not client_id:
        return HttpResponse("FusionAuth is not configured.", status=503, content_type="text/plain")
    state = secrets.token_urlsafe(32)
    verifier = secrets.token_urlsafe(64)
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    request.session[SESSION_STATE] = state
    request.session[SESSION_VERIFIER] = verifier
    request.session[SESSION_NEXT] = _safe_next(request, request.GET.get("next"))
    redirect_uri = request.build_absolute_uri(reverse("accounts:callback"))
    parameters = {
        "client_id": client_id,
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": _setting("FUSIONAUTH_SCOPES", "openid profile email"),
        "state": state,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
    }
    authorize_url = _endpoint("FUSIONAUTH_AUTHORIZE_URL", "/oauth2/authorize")
    return redirect(f"{authorize_url}?{urlencode(parameters)}")


@require_GET
def oidc_callback(request):
    expected_state = request.session.pop(SESSION_STATE, "")
    verifier = request.session.pop(SESSION_VERIFIER, "")
    destination = request.session.pop(SESSION_NEXT, "/")
    state = request.GET.get("state", "")
    if not expected_state or not state or not secrets.compare_digest(expected_state, state):
        return HttpResponse("Invalid OIDC state.", status=400, content_type="text/plain")
    if request.GET.get("error"):
        return HttpResponse(
            f"FusionAuth rejected login: {request.GET['error']}",
            status=400,
            content_type="text/plain",
        )
    code = request.GET.get("code", "")
    if not code or not verifier:
        return HttpResponse(
            "Missing OIDC authorization code.", status=400, content_type="text/plain"
        )

    redirect_uri = request.build_absolute_uri(reverse("accounts:callback"))
    token_data = {
        "grant_type": "authorization_code",
        "client_id": _setting("FUSIONAUTH_CLIENT_ID"),
        "code": code,
        "redirect_uri": redirect_uri,
        "code_verifier": verifier,
    }
    client_secret = _setting("FUSIONAUTH_CLIENT_SECRET")
    if client_secret:
        token_data["client_secret"] = client_secret
    try:
        timeout = float(getattr(settings, "FUSIONAUTH_HTTP_TIMEOUT", 10))
        with httpx.Client(timeout=timeout) as client:
            token_response = client.post(
                _endpoint("FUSIONAUTH_TOKEN_URL", "/oauth2/token"), data=token_data
            )
            token_response.raise_for_status()
            access_token = token_response.json()["access_token"]
            userinfo_response = client.get(
                _endpoint("FUSIONAUTH_USERINFO_URL", "/oauth2/userinfo"),
                headers={"Authorization": f"Bearer {access_token}"},
            )
            userinfo_response.raise_for_status()
            claims = userinfo_response.json()
    except (httpx.HTTPError, KeyError, ValueError) as exc:
        return HttpResponse(
            f"FusionAuth login could not be completed ({exc.__class__.__name__}).",
            status=502,
            content_type="text/plain",
        )

    user = FusionAuthOIDCAdapter().get_or_create_user(claims)
    backend = getattr(
        settings,
        "FUSIONAUTH_LOGIN_BACKEND",
        "django.contrib.auth.backends.ModelBackend",
    )
    login(request, user, backend=backend)
    return redirect(_safe_next(request, destination))


@require_http_methods(["GET", "POST"])
def oidc_logout(request):
    logout(request)
    destination = _safe_next(request, request.GET.get("next"), "/")
    client_id = _setting("FUSIONAUTH_CLIENT_ID")
    if not client_id:
        return redirect(destination)
    post_logout_uri = request.build_absolute_uri(destination)
    parameters = {"client_id": client_id, "post_logout_redirect_uri": post_logout_uri}
    logout_url = _endpoint("FUSIONAUTH_LOGOUT_URL", "/oauth2/logout")
    return redirect(f"{logout_url}?{urlencode(parameters)}")


@require_GET
def auth_status(request):
    return JsonResponse(
        {
            "authenticated": request.user.is_authenticated,
            "user": request.user.get_username() if request.user.is_authenticated else None,
        }
    )
