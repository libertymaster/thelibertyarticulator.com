from django.conf import settings
from django.http import HttpResponseForbidden
from wagtail import hooks


@hooks.register("construct_settings_menu")
def hide_managed_user_menu(request, menu_items):
    if getattr(settings, "FUSIONAUTH_MANAGED_USERS", False) and not request.user.is_superuser:
        menu_items[:] = [item for item in menu_items if item.name not in {"users", "groups"}]


@hooks.register("before_create_user")
def prevent_local_user_creation(request):
    if getattr(settings, "FUSIONAUTH_MANAGED_USERS", False) and not request.user.is_superuser:
        return HttpResponseForbidden("Users are managed through FusionAuth.")
    return None
