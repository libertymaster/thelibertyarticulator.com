from django.shortcuts import get_object_or_404, render

from apps.publications.selectors import publications_by_person

from .models import Person


def person_list(request):
    people = Person.objects.filter(is_active=True).select_related("portrait")
    return render(request, "people/person_list.html", {"people": people})


def person_detail(request, slug):
    person = get_object_or_404(Person.objects.select_related("portrait"), slug=slug, is_active=True)
    publications = publications_by_person(person)
    return render(
        request,
        "people/person_detail.html",
        {"person": person, "publications": publications},
    )
