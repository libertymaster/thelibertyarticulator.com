from wagtail import hooks
from wagtail.snippets.views.snippets import SnippetViewSet

from .models import Person


class PersonViewSet(SnippetViewSet):
    model = Person
    icon = "user"
    menu_label = "People"
    list_display = ("name", "affiliation", "orcid", "is_active")
    list_filter = ("is_active",)
    search_fields = ("name", "family_name", "affiliation", "orcid")


@hooks.register("register_admin_viewset")
def register_person_viewset():
    return PersonViewSet(name="people")
