from django.urls import path

from . import views

app_name = "people"

urlpatterns = [
    path("", views.person_list, name="index"),
    path("<slug:slug>/", views.person_detail, name="detail"),
]
