from typing import ClassVar

from django.contrib import admin

from .models import Person


@admin.register(Person)
class PersonAdmin(admin.ModelAdmin):
    list_display = ("name", "affiliation", "orcid", "is_active", "updated_at")
    list_filter = ("is_active",)
    prepopulated_fields: ClassVar[dict[str, tuple[str, ...]]] = {"slug": ("name",)}
    search_fields = ("name", "given_name", "family_name", "affiliation", "orcid")
