import django.db.models.deletion
import wagtail.fields
from django.conf import settings
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ("wagtailimages", "0026_delete_uploadedimage"),
    ]

    operations = [
        migrations.CreateModel(
            name="Person",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("created_at", models.DateTimeField(auto_now_add=True, db_index=True)),
                ("updated_at", models.DateTimeField(auto_now=True)),
                ("name", models.CharField(max_length=200)),
                ("slug", models.SlugField(blank=True, max_length=220, unique=True)),
                ("given_name", models.CharField(blank=True, max_length=100)),
                ("family_name", models.CharField(blank=True, max_length=100)),
                ("honorific", models.CharField(blank=True, max_length=50)),
                ("biography", wagtail.fields.RichTextField(blank=True)),
                ("affiliation", models.CharField(blank=True, max_length=240)),
                ("email", models.EmailField(blank=True, help_text="Kept private unless a template explicitly displays it.", max_length=254)),
                ("website", models.URLField(blank=True)),
                ("orcid", models.CharField(blank=True, max_length=19, null=True, unique=True)),
                ("is_active", models.BooleanField(db_index=True, default=True)),
                ("created_by", models.ForeignKey(blank=True, editable=False, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="people_person_created", to=settings.AUTH_USER_MODEL)),
                ("portrait", models.ForeignKey(blank=True, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="+", to="wagtailimages.image")),
                ("updated_by", models.ForeignKey(blank=True, editable=False, null=True, on_delete=django.db.models.deletion.SET_NULL, related_name="people_person_updated", to=settings.AUTH_USER_MODEL)),
            ],
            options={"verbose_name_plural": "people", "ordering": ("family_name", "given_name", "name")},
        )
    ]

