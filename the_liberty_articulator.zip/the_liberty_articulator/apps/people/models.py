from __future__ import annotations

import re
from typing import ClassVar

from django.core.exceptions import ValidationError
from django.db import models
from django.urls import reverse
from django.utils.text import slugify
from wagtail.admin.panels import FieldPanel, MultiFieldPanel
from wagtail.fields import RichTextField
from wagtail.search import index

from apps.core.models import AuditableModel

ORCID_RE = re.compile(r"^(?:https?://orcid\.org/)?(\d{4}-\d{4}-\d{4}-\d{3}[\dX])$", re.I)


def normalize_orcid(value: str | None) -> str:
    value = (value or "").strip()
    if not value:
        return ""
    match = ORCID_RE.fullmatch(value)
    if not match:
        raise ValidationError("Enter an ORCID such as 0000-0002-1825-0097.")
    identifier = match.group(1).upper()
    digits = identifier.replace("-", "")
    total = 0
    for character in digits[:15]:
        total = (total + int(character)) * 2
    check_value = (12 - (total % 11)) % 11
    check = "X" if check_value == 10 else str(check_value)
    if digits[-1] != check:
        raise ValidationError("The ORCID check digit is invalid.")
    return identifier


class Person(index.Indexed, AuditableModel):
    name = models.CharField(max_length=200)
    slug = models.SlugField(max_length=220, unique=True, blank=True)
    given_name = models.CharField(max_length=100, blank=True)
    family_name = models.CharField(max_length=100, blank=True)
    honorific = models.CharField(max_length=50, blank=True)
    biography = RichTextField(blank=True)
    affiliation = models.CharField(max_length=240, blank=True)
    email = models.EmailField(
        blank=True,
        help_text="Kept private unless a template explicitly displays it.",
    )
    website = models.URLField(blank=True)
    orcid = models.CharField(max_length=19, blank=True, unique=True, null=True)
    portrait = models.ForeignKey(
        "wagtailimages.Image",
        blank=True,
        null=True,
        on_delete=models.SET_NULL,
        related_name="+",
    )
    is_active = models.BooleanField(default=True, db_index=True)

    panels: ClassVar[list] = [
        FieldPanel("name"),
        FieldPanel("slug"),
        MultiFieldPanel(
            [FieldPanel("honorific"), FieldPanel("given_name"), FieldPanel("family_name")],
            heading="Structured name",
        ),
        FieldPanel("biography"),
        FieldPanel("portrait"),
        MultiFieldPanel(
            [
                FieldPanel("affiliation"),
                FieldPanel("orcid"),
                FieldPanel("website"),
                FieldPanel("email"),
            ],
            heading="Identity and contact",
        ),
        FieldPanel("is_active"),
    ]
    search_fields: ClassVar[list] = [
        index.SearchField("name", partial_match=True, boost=3),
        index.SearchField("given_name", partial_match=True),
        index.SearchField("family_name", partial_match=True),
        index.SearchField("biography"),
        index.SearchField("affiliation"),
        index.FilterField("is_active"),
    ]

    class Meta:
        ordering = ("family_name", "given_name", "name")
        verbose_name_plural = "people"

    def __str__(self) -> str:
        return self.name

    @property
    def orcid_url(self) -> str:
        return f"https://orcid.org/{self.orcid}" if self.orcid else ""

    def clean(self) -> None:
        super().clean()
        self.orcid = normalize_orcid(self.orcid) or None

    def save(self, *args, **kwargs):
        self.orcid = normalize_orcid(self.orcid) or None
        if not self.slug:
            base = slugify(self.name)[:200] or "person"
            candidate = base
            counter = 2
            while type(self).objects.exclude(pk=self.pk).filter(slug=candidate).exists():
                candidate = f"{base[: 214 - len(str(counter))]}-{counter}"
                counter += 1
            self.slug = candidate
        return super().save(*args, **kwargs)

    def get_absolute_url(self) -> str:
        return reverse("people:detail", kwargs={"slug": self.slug})
