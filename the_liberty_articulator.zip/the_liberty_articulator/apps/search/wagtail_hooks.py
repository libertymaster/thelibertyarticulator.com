from wagtail import hooks
from wagtail.admin.search import SearchArea


@hooks.register("register_admin_search_area")
def register_public_search():
    return SearchArea("Public site", "/search/", name="public-site", icon_name="search", order=900)
