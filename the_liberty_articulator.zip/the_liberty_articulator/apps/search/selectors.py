from __future__ import annotations

from dataclasses import dataclass

from django.db.models import Q
from django.utils.html import strip_tags

from apps.people.models import Person
from apps.publications.models import PublicationPage
from apps.publications.selectors import public_publications
from apps.references.models import Source


@dataclass(frozen=True, slots=True)
class SearchHit:
    kind: str
    title: str
    summary: str
    url: str
    object: object

    @property
    def description(self) -> str:
        return self.summary

    def get_verbose_name(self) -> str:
        labels = {
            "publication": "Publication",
            "person": "Contributor",
            "source": "Source",
        }
        return labels.get(self.kind, "Journal record")


def _backend_search(queryset, query: str, fallback_filter: Q):
    try:
        return queryset.search(query, operator="and")
    except AttributeError, NotImplementedError, RuntimeError:
        return queryset.filter(fallback_filter)


def publication_results(query: str):
    return _backend_search(
        public_publications(),
        query,
        Q(title__icontains=query)
        | Q(subtitle__icontains=query)
        | Q(dek__icontains=query)
        | Q(abstract__icontains=query)
        | Q(body__icontains=query),
    )


def person_results(query: str):
    people = Person.objects.filter(is_active=True).select_related("portrait")
    return _backend_search(
        people,
        query,
        Q(name__icontains=query)
        | Q(given_name__icontains=query)
        | Q(family_name__icontains=query)
        | Q(biography__icontains=query)
        | Q(affiliation__icontains=query),
    )


def source_results(query: str):
    sources = Source.objects.filter(is_active=True)
    return _backend_search(
        sources,
        query,
        Q(title__icontains=query)
        | Q(container_title__icontains=query)
        | Q(publisher__icontains=query)
        | Q(abstract__icontains=query)
        | Q(doi__icontains=query),
    )


def _publication_hit(publication: PublicationPage) -> SearchHit:
    return SearchHit(
        "publication",
        publication.title,
        publication.dek or publication.abstract,
        publication.get_absolute_url(),
        publication,
    )


def _person_hit(person: Person) -> SearchHit:
    return SearchHit(
        "person",
        person.name,
        strip_tags(str(person.biography))[:320] or person.affiliation,
        person.get_absolute_url(),
        person,
    )


def _source_hit(source: Source) -> SearchHit:
    return SearchHit(
        "source",
        source.title,
        source.abstract[:320] or source.container_title,
        source.get_absolute_url(),
        source,
    )


def search_all(query: str, *, content_type: str = "all") -> list[SearchHit]:
    """Search indexed domain models, preserving backend relevance within each type."""

    query = query.strip()[:200]
    if not query:
        return []
    if content_type == "publication":
        return [_publication_hit(item) for item in publication_results(query)]
    if content_type == "person":
        return [_person_hit(item) for item in person_results(query)]
    if content_type == "source":
        return [_source_hit(item) for item in source_results(query)]
    results: list[SearchHit] = []
    results.extend(_publication_hit(item) for item in publication_results(query)[:100])
    results.extend(_person_hit(item) for item in person_results(query)[:40])
    results.extend(_source_hit(item) for item in source_results(query)[:80])
    return results
