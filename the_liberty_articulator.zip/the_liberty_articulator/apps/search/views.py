import logging

from django.apps import apps
from django.core.paginator import Paginator
from django.shortcuts import render

from .selectors import search_all

logger = logging.getLogger(__name__)


def search(request):
    query = request.GET.get("q", "").strip()[:200]
    content_type = request.GET.get("type", "all")
    if content_type not in {"all", "publication", "person", "source"}:
        content_type = "all"
    hits = search_all(query, content_type=content_type)
    page = Paginator(hits, 20).get_page(request.GET.get("page"))
    if query and apps.is_installed("wagtail.contrib.search_promotions"):
        try:
            from wagtail.contrib.search_promotions.models import Query

            Query.get(query).add_hit()
        except Exception:
            # Search remains useful if promotions are not migrated or use a remote backend.
            logger.debug("Could not record a promoted-search query hit", exc_info=True)
    return render(
        request,
        "search/search.html",
        {
            "query": query,
            "content_type": content_type,
            "page_obj": page,
            "search_results": page.object_list,
            "result_count": len(hits),
            "content_types": (
                ("all", "All"),
                ("publication", "Publications"),
                ("person", "People"),
                ("source", "Sources"),
            ),
        },
    )
