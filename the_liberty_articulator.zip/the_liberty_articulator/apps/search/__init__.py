"""Cross-content public search."""
