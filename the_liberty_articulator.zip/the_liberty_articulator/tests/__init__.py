"""Test suite for The Liberty Articulator."""
