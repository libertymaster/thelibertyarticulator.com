from __future__ import annotations


def test_reader_can_discover_and_open_cited_publication(client, publication_record):
    home = client.get("/")
    assert home.status_code == 200
    assert b"The Long Memory of Liberty" in home.content

    archive = client.get(
        "/publications/",
        {"category": publication_record.category.slug, "q": "memory"},
    )
    assert archive.status_code == 200
    assert b"The Long Memory of Liberty" in archive.content

    detail = client.get(publication_record.publication.get_absolute_url())
    assert detail.status_code == 200
    assert b"Mara Ellison" in detail.content
    assert b"Two Treatises of Government" in detail.content
    assert b"application/ld+json" in detail.content

    contributor = client.get(publication_record.author.get_absolute_url())
    assert contributor.status_code == 200
    assert b"The Long Memory of Liberty" in contributor.content

    source = client.get(publication_record.source.get_absolute_url())
    assert source.status_code == 200
    assert b"Two Treatises of Government" in source.content
