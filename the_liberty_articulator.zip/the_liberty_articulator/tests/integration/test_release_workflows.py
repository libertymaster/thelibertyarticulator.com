from __future__ import annotations

from io import StringIO
from urllib.parse import parse_qs, urlparse

import httpx
import pytest
from django.contrib.auth import get_user_model
from django.core.exceptions import PermissionDenied, ValidationError
from django.core.management import call_command
from django.urls import reverse

from apps.publications.models import PublicationPage, Version
from apps.publications.services import (
    approve,
    publish,
    request_changes,
    submit_for_review,
    transition_publication,
)


class _OIDCClient:
    def __init__(self, *args, **kwargs):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *args):
        return False

    def post(self, url, data):
        request = httpx.Request("POST", url)
        return httpx.Response(200, json={"access_token": "verified-token"}, request=request)

    def get(self, url, headers):
        request = httpx.Request("GET", url)
        return httpx.Response(
            200,
            json={
                "sub": "fusionauth-subject-42",
                "email": "Editor@Example.com",
                "given_name": "Ada",
                "family_name": "Lovelace",
                "roles": ["editor"],
            },
            request=request,
        )


@pytest.mark.django_db
def test_seed_command_is_complete_and_idempotent(client):
    first_output = StringIO()
    call_command("seed_demo", stdout=first_output)
    first_versions = Version.objects.count()

    second_output = StringIO()
    call_command("seed_demo", stdout=second_output)

    assert (
        PublicationPage.objects.filter(
            editorial_status=PublicationPage.EditorialStatus.PUBLISHED
        ).count()
        == 4
    )
    assert Version.objects.count() == first_versions == 4
    assert "4 publications created" in first_output.getvalue()
    assert "4 refreshed" in second_output.getvalue()
    assert client.get("/").status_code == 200


@pytest.mark.django_db
def test_oidc_pkce_login_callback_status_and_logout(client, settings, monkeypatch):
    settings.FUSIONAUTH_CLIENT_ID = "liberty-web"
    settings.FUSIONAUTH_ADMIN_ROLES = ("editor",)
    settings.FUSIONAUTH_AUTHORIZE_URL = "https://auth.example.test/oauth2/authorize"
    settings.FUSIONAUTH_TOKEN_URL = "https://auth.example.test/oauth2/token"
    settings.FUSIONAUTH_USERINFO_URL = "https://auth.example.test/oauth2/userinfo"
    settings.FUSIONAUTH_LOGOUT_URL = "https://auth.example.test/oauth2/logout"
    monkeypatch.setattr("apps.accounts.views.httpx.Client", _OIDCClient)

    login = client.get(reverse("accounts:login"), {"next": "/publications/"})
    assert login.status_code == 302
    parameters = parse_qs(urlparse(login.url).query)
    assert parameters["code_challenge_method"] == ["S256"]
    assert parameters["scope"] == ["openid profile email"]

    callback = client.get(
        reverse("accounts:callback"),
        {"state": parameters["state"][0], "code": "authorization-code"},
    )
    assert callback.status_code == 302
    assert callback.url == "/publications/"

    user = get_user_model().objects.get()
    assert user.email == "editor@example.com"
    assert (user.first_name, user.last_name) == ("Ada", "Lovelace")
    assert user.is_staff
    assert not user.has_usable_password()
    assert client.get(reverse("accounts:status")).json() == {
        "authenticated": True,
        "user": user.username,
    }

    logout = client.post(reverse("accounts:logout"), {"next": "/"})
    assert logout.status_code == 302
    assert logout.url.startswith("https://auth.example.test/oauth2/logout?")
    assert not client.get(reverse("accounts:status")).json()["authenticated"]


@pytest.mark.django_db
def test_oidc_callback_reports_provider_and_protocol_failures(client, settings, monkeypatch):
    settings.FUSIONAUTH_CLIENT_ID = "liberty-web"

    session = client.session
    session["fusionauth_oidc_state"] = "expected"
    session["fusionauth_oidc_verifier"] = "verifier"
    session.save()
    denied = client.get(
        reverse("accounts:callback"),
        {"state": "expected", "error": "access_denied"},
    )
    assert denied.status_code == 400
    assert b"access_denied" in denied.content

    session = client.session
    session["fusionauth_oidc_state"] = "expected"
    session["fusionauth_oidc_verifier"] = "verifier"
    session.save()
    missing = client.get(reverse("accounts:callback"), {"state": "expected"})
    assert missing.status_code == 400
    assert b"Missing OIDC authorization code" in missing.content

    class FailingClient(_OIDCClient):
        def post(self, url, data):
            raise httpx.ConnectError("provider unavailable", request=httpx.Request("POST", url))

    monkeypatch.setattr("apps.accounts.views.httpx.Client", FailingClient)
    session = client.session
    session["fusionauth_oidc_state"] = "expected"
    session["fusionauth_oidc_verifier"] = "verifier"
    session.save()
    unavailable = client.get(
        reverse("accounts:callback"),
        {"state": "expected", "code": "code"},
    )
    assert unavailable.status_code == 502
    assert b"ConnectError" in unavailable.content


def test_editorial_workflow_validates_and_records_each_transition(publication_record):
    publication = publication_record.publication
    publication.editorial_status = PublicationPage.EditorialStatus.DRAFT
    publication.live = False
    publication.save(update_fields=("editorial_status", "live"))

    with pytest.raises(ValidationError):
        transition_publication(publication, "unknown")
    with pytest.raises(ValidationError):
        transition_publication(publication, PublicationPage.EditorialStatus.APPROVED)

    publication = submit_for_review(publication, note="Ready for review")
    publication = request_changes(publication, note="Tighten the evidence")
    publication = submit_for_review(publication, note="Revised")
    publication = approve(publication, note="Approved")
    publication = publish(publication, note="Released")

    assert publication.editorial_status == PublicationPage.EditorialStatus.PUBLISHED
    assert publication.published_at is not None
    assert publication.live
    assert Version.objects.filter(publication=publication).count() == 5

    publication = transition_publication(publication, PublicationPage.EditorialStatus.ARCHIVED)
    assert publication.editorial_status == PublicationPage.EditorialStatus.ARCHIVED
    assert not publication.live


def test_editorial_transition_enforces_page_permissions(publication_record, django_user_model):
    publication = publication_record.publication
    publication.editorial_status = PublicationPage.EditorialStatus.DRAFT
    publication.save(update_fields=("editorial_status",))
    reader = django_user_model.objects.create_user(username="reader", password="unused")

    with pytest.raises(PermissionDenied):
        submit_for_review(publication, actor=reader)


def test_public_indexes_and_filters_render(client, publication_record):
    assert client.get("/people/").status_code == 200
    assert client.get("/series/").status_code == 200
    assert client.get("/publications/").status_code == 200
    assert client.get("/sources/").status_code == 200
    assert client.get(publication_record.series.get_absolute_url()).status_code == 200

    sources = client.get("/sources/", {"q": "Treatises", "year": "not-a-year"})
    assert sources.status_code == 200
    assert b"Two Treatises of Government" in sources.content
    assert publication_record.source.get_absolute_url().encode() in sources.content

    search = client.get("/search/", {"q": "Mara", "type": "invalid"})
    assert search.status_code == 200
    assert search.context["content_type"] == "all"
