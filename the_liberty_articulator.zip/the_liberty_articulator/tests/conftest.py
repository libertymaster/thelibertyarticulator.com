from __future__ import annotations

from types import SimpleNamespace

import pytest
from django.utils import timezone
from wagtail.models import Page

from apps.people.models import Person
from apps.publications.models import Contributor, PublicationPage, PublicationSource
from apps.references.models import Source
from apps.series.models import Series
from apps.taxonomy.models import Category, Keyword


@pytest.fixture
def publication_record(db):
    """A complete live publication and its structured editorial relations."""

    author = Person.objects.create(
        name="Mara Ellison",
        given_name="Mara",
        family_name="Ellison",
        affiliation="Center for Civic Memory",
        orcid="0000-0002-1825-0097",
    )
    category = Category.objects.create(
        name="Constitutional History",
        slug="constitutional-history",
    )
    keyword = Keyword.objects.create(name="Civic memory", slug="civic-memory")
    source = Source.objects.create(
        title="Two Treatises of Government",
        authors=[{"family": "Locke", "given": "John"}],
        publication_year=1689,
        source_type=Source.Type.BOOK,
        doi="https://doi.org/10.0000/example",
    )
    series = Series.objects.create(
        title="The Architecture of Freedom",
        tagline="Institutions, choices, and historical memory",
        editor=author,
        start_year=2026,
    )
    publication = PublicationPage(
        title="The Long Memory of Liberty",
        slug="long-memory-of-liberty",
        subtitle="How institutions preserve—and revise—civic inheritance",
        dek="A close reading of the stories institutions tell about freedom.",
        abstract="Historical memory shapes the boundaries of political possibility.",
        body=(
            "<p>Liberty lives in documents, practices, and contested memory.</p>"
            "<h2>Institutions remember</h2><p>Evidence changes the questions we ask.</p>"
        ),
        editorial_status=PublicationPage.EditorialStatus.PUBLISHED,
        published_at=timezone.now(),
        featured=True,
        peer_reviewed=True,
        series=series,
    )
    Page.get_first_root_node().add_child(instance=publication)
    publication.categories.add(category)
    publication.keywords.add(keyword)
    publication.save()
    Contributor.objects.create(
        publication=publication,
        person=author,
        role=Contributor.Role.AUTHOR,
        sort_order=0,
    )
    PublicationSource.objects.create(
        publication=publication,
        source=source,
        locator="II, §57",
        sort_order=0,
    )
    publication.refresh_from_db()
    return SimpleNamespace(
        publication=publication,
        author=author,
        category=category,
        keyword=keyword,
        source=source,
        series=series,
    )
