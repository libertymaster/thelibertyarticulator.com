from __future__ import annotations

from django.urls import reverse


def test_unconfigured_login_is_explicitly_unavailable(client):
    response = client.get(reverse("accounts:login"))
    assert response.status_code == 503
    assert b"not configured" in response.content


def test_callback_requires_matching_state(client):
    response = client.get(reverse("accounts:callback"), {"state": "wrong", "code": "code"})
    assert response.status_code == 400
    assert b"Invalid OIDC state" in response.content


def test_auth_status_for_anonymous_user(client):
    response = client.get(reverse("accounts:status"))
    assert response.status_code == 200
    assert response.json() == {"authenticated": False, "user": None}
