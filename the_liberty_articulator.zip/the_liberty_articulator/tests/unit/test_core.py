from __future__ import annotations

from django.urls import reverse


def test_health_readiness_and_metrics(client, db):
    health = client.get(reverse("core:health"))
    assert health.status_code == 200
    assert health.json() == {"status": "ok"}
    assert health.headers["X-Request-ID"]
    assert health.headers["Permissions-Policy"].startswith("camera=()")

    ready = client.get(reverse("core:ready"))
    assert ready.status_code == 200
    assert ready.json()["checks"] == {"database": "ok", "cache": "ok"}

    metrics = client.get(reverse("core:metrics"))
    assert metrics.status_code == 200
    assert b"python_info" in metrics.content or b"articulator_up" in metrics.content


def test_request_id_rejects_unsafe_header(client):
    response = client.get(reverse("core:health"), headers={"X-Request-ID": "bad\r\nheader"})
    assert response.status_code == 200
    assert response.headers["X-Request-ID"] != "bad\r\nheader"


def test_error_pages_render(client, settings, db):
    settings.DEBUG = False
    missing = client.get("/does-not-exist/")
    assert missing.status_code == 404
    assert b"This page has slipped from view" in missing.content
