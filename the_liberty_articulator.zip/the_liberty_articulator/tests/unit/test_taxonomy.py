from __future__ import annotations

import pytest
from django.core.exceptions import ValidationError

from apps.taxonomy.models import Category


def test_category_ancestry_and_cycle_validation(db):
    parent = Category.objects.create(name="History", slug="history")
    child = Category.objects.create(name="Constitutional", slug="constitutional", parent=parent)
    assert str(child) == "History / Constitutional"
    assert child.ancestors(include_self=True) == [parent, child]

    parent.parent = child
    with pytest.raises(ValidationError):
        parent.full_clean()
