from __future__ import annotations

from apps.references.models import Source
from apps.references.services import render_citation, source_to_csl_json


def test_source_normalizes_identifiers_and_exports_csl(db):
    source = Source.objects.create(
        title="A Letter Concerning Toleration",
        authors=[{"family": "Locke", "given": "John"}],
        publication_year=1689,
        source_type=Source.Type.BOOK,
        doi="doi: 10.1234/Liberty.1",
    )
    assert source.doi == "10.1234/Liberty.1"
    assert source.slug == "a-letter-concerning-toleration"
    assert source.citation_key.startswith("locke-1689")

    payload = source_to_csl_json(source)
    assert payload["title"] == source.title
    assert payload["author"][0]["family"] == "Locke"
    assert payload["issued"] == {"date-parts": [[1689]]}
    assert "Locke" in render_citation(source)
    assert source.doi_url.endswith("10.1234/Liberty.1")


def test_source_detail_can_return_csl_json(client, db):
    source = Source.objects.create(title="The Federalist", publication_year=1788)
    response = client.get(source.get_absolute_url(), {"format": "csl-json"})
    assert response.status_code == 200
    assert response.json()["title"] == "The Federalist"
