from __future__ import annotations

import json
from datetime import timedelta

import pytest
from django.core.exceptions import ValidationError
from django.utils import timezone
from wagtail.models import Page

from apps.publications.models import PublicationPage
from apps.publications.selectors import public_publications
from apps.publications.services import (
    available_transitions,
    create_version,
    publication_schema,
    publication_schema_json,
)


def test_publication_relations_and_schema(publication_record):
    publication = publication_record.publication
    assert publication.byline == "Mara Ellison"
    assert publication.reading_time == 1
    assert publication.is_publicly_available

    schema = publication_schema(publication)
    assert schema["@type"] == "ScholarlyArticle"
    assert schema["author"][0]["name"] == "Mara Ellison"
    assert schema["citation"][0]["title"] == "Two Treatises of Government"
    assert schema["articleSection"] == ["Constitutional History"]
    assert json.loads(publication_schema_json(publication))["headline"] == publication.title


def test_json_ld_escapes_script_breakout(publication_record):
    publication = publication_record.publication
    publication.title = "A title </script><script>alert(1)</script>"
    encoded = publication_schema_json(publication)
    assert "</script>" not in encoded.lower()
    assert "\\u003c/script\\u003e" in encoded.lower()


def test_public_selector_excludes_future_embargo(db):
    publication = PublicationPage(
        title="Embargoed essay",
        slug="embargoed-essay",
        editorial_status=PublicationPage.EditorialStatus.PUBLISHED,
        published_at=timezone.now(),
        embargo_until=timezone.now() + timedelta(days=1),
    )
    Page.get_first_root_node().add_child(instance=publication)
    assert publication.pk not in public_publications().values_list("pk", flat=True)


def test_versions_increment_and_snapshots_are_immutable(publication_record):
    publication = publication_record.publication
    first = create_version(publication, change_summary="Editorial review")
    second = create_version(publication, change_summary="Approved")
    first.refresh_from_db()

    assert (first.number, first.is_current) == (1, False)
    assert (second.number, second.is_current) == (2, True)
    second.snapshot = {"changed": True}
    with pytest.raises(ValidationError):
        second.save()


def test_transition_map(publication_record):
    publication = publication_record.publication
    assert available_transitions(publication) == (PublicationPage.EditorialStatus.ARCHIVED,)
