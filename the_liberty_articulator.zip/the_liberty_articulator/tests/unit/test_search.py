from __future__ import annotations

from apps.search.selectors import search_all


def test_search_returns_structured_hits(client, publication_record):
    hits = search_all("Liberty")
    assert any(hit.title == "The Long Memory of Liberty" for hit in hits)

    response = client.get("/search/", {"q": "Liberty"})
    assert response.status_code == 200
    assert b"The Long Memory of Liberty" in response.content
    assert response.context["result_count"] >= 1


def test_blank_search_is_an_empty_state(client, db):
    response = client.get("/search/")
    assert response.status_code == 200
    assert response.context["result_count"] == 0
