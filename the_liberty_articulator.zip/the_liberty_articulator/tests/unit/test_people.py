from __future__ import annotations

import pytest
from django.core.exceptions import ValidationError

from apps.people.models import Person, normalize_orcid


def test_orcid_is_normalized_and_validated(db):
    assert normalize_orcid("https://orcid.org/0000-0002-1825-0097") == "0000-0002-1825-0097"
    with pytest.raises(ValidationError):
        normalize_orcid("0000-0002-1825-0098")

    person = Person.objects.create(name="Mara Ellison", orcid="0000-0002-1825-0097")
    assert person.slug == "mara-ellison"
    assert person.orcid_url == "https://orcid.org/0000-0002-1825-0097"


def test_person_slugs_are_unique(db):
    first = Person.objects.create(name="Alex Morgan")
    second = Person.objects.create(name="Alex Morgan")
    assert first.slug == "alex-morgan"
    assert second.slug == "alex-morgan-2"
