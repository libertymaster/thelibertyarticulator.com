#!/usr/bin/env python3
"""Minimal authenticated deployment webhook.

The handler accepts a narrowly scoped, GitHub-compatible JSON payload, validates
its HMAC signature, repository, ref, and commit SHA, then invokes one fixed local
deployment script. Payload values are never interpreted by a shell.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os
import re
import subprocess
import threading
import time
from collections import deque
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

LOG = logging.getLogger("liberty-deploy-webhook")
SHA_PATTERN = re.compile(r"^[0-9a-f]{40}(?:[0-9a-f]{24})?$")
DELIVERY_PATTERN = re.compile(r"^[A-Za-z0-9._:-]{1,128}$")


def required_environment(name: str) -> str:
    value = os.environ.get(name, "").strip()
    if not value:
        raise RuntimeError(f"{name} must be set")
    return value


class Configuration:
    def __init__(self) -> None:
        self.secret = required_environment("WEBHOOK_SECRET").encode("utf-8")
        self.allowed_repository = required_environment("ALLOWED_REPOSITORY")
        self.allowed_ref = os.environ.get("ALLOWED_REF", "refs/heads/main")
        self.listen_host = os.environ.get("LISTEN_HOST", "127.0.0.1")
        self.listen_port = int(os.environ.get("LISTEN_PORT", "9080"))
        self.max_body_bytes = int(os.environ.get("MAX_BODY_BYTES", "1048576"))
        self.deploy_timeout_seconds = int(os.environ.get("DEPLOY_TIMEOUT_SECONDS", "1800"))
        self.deploy_script = Path(required_environment("DEPLOY_SCRIPT"))
        self.state_file = Path(
            os.environ.get("DEPLOY_STATE_FILE", "/var/lib/liberty-deploy/status.json")
        )

        if not self.deploy_script.is_absolute():
            raise RuntimeError("DEPLOY_SCRIPT must be an absolute path")
        if not self.deploy_script.is_file() or not os.access(self.deploy_script, os.X_OK):
            raise RuntimeError("DEPLOY_SCRIPT must be an executable regular file")
        if not 1024 <= self.listen_port <= 65535:
            raise RuntimeError("LISTEN_PORT must be between 1024 and 65535")
        if not 1024 <= self.max_body_bytes <= 10 * 1024 * 1024:
            raise RuntimeError("MAX_BODY_BYTES is outside the accepted range")


CONFIG = Configuration()
DEPLOYMENT_LOCK = threading.Lock()
DELIVERY_LOCK = threading.Lock()
RECENT_DELIVERIES: deque[str] = deque(maxlen=512)
RECENT_DELIVERY_SET: set[str] = set()


def write_state(**values: Any) -> None:
    payload = {"updated_at": int(time.time()), **values}
    CONFIG.state_file.parent.mkdir(parents=True, exist_ok=True)
    temporary = CONFIG.state_file.with_suffix(".tmp")
    temporary.write_text(json.dumps(payload, sort_keys=True) + "\n", encoding="utf-8")
    os.chmod(temporary, 0o600)
    temporary.replace(CONFIG.state_file)


def remember_delivery(delivery: str) -> bool:
    """Return False when this delivery was already accepted."""
    with DELIVERY_LOCK:
        if delivery in RECENT_DELIVERY_SET:
            return False
        if len(RECENT_DELIVERIES) == RECENT_DELIVERIES.maxlen:
            RECENT_DELIVERY_SET.discard(RECENT_DELIVERIES[0])
        RECENT_DELIVERIES.append(delivery)
        RECENT_DELIVERY_SET.add(delivery)
        return True


def normalized_ref(value: str) -> str:
    return value if value.startswith("refs/") else f"refs/heads/{value}"


def deployment_details(event: str, payload: dict[str, Any]) -> tuple[str, str, str]:
    repository = payload.get("repository") or {}
    repository_name = repository.get("full_name", "")

    if event == "workflow_run":
        workflow_run = payload.get("workflow_run") or {}
        if payload.get("action") != "completed" or workflow_run.get("conclusion") != "success":
            raise ValueError("workflow_run is not a completed success")
        ref = normalized_ref(str(workflow_run.get("head_branch", "")))
        sha = str(workflow_run.get("head_sha", ""))
    elif event == "repository_dispatch":
        client_payload = payload.get("client_payload") or {}
        ref = normalized_ref(str(client_payload.get("ref", payload.get("ref", ""))))
        sha = str(client_payload.get("sha", payload.get("sha", "")))
    elif event == "push":
        ref = str(payload.get("ref", ""))
        sha = str(payload.get("after", ""))
    else:
        raise ValueError(f"event is not accepted: {event}")

    return repository_name, ref, sha.lower()


def run_deployment(sha: str, delivery: str) -> None:
    with DEPLOYMENT_LOCK:
        write_state(status="running", sha=sha, delivery=delivery)
        LOG.info("deployment started sha=%s delivery=%s", sha, delivery)
        try:
            # The executable is an absolute, startup-validated regular file; both
            # arguments are regex-validated and no shell is involved.
            result = subprocess.run(  # noqa: S603
                [str(CONFIG.deploy_script), sha, delivery],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                timeout=CONFIG.deploy_timeout_seconds,
                check=False,
                env={**os.environ, "GIT_COMMIT_SHA": sha, "WEBHOOK_DELIVERY": delivery},
            )
            output = result.stdout[-16_384:]
            if result.returncode:
                LOG.error(
                    "deployment failed sha=%s returncode=%s output=%s",
                    sha,
                    result.returncode,
                    output,
                )
                write_state(
                    status="failed",
                    sha=sha,
                    delivery=delivery,
                    returncode=result.returncode,
                )
                return

            LOG.info("deployment completed sha=%s output=%s", sha, output)
            write_state(status="succeeded", sha=sha, delivery=delivery, returncode=0)
        except subprocess.TimeoutExpired:
            LOG.exception("deployment timed out sha=%s", sha)
            write_state(status="timed_out", sha=sha, delivery=delivery)
        except Exception:
            LOG.exception("deployment worker crashed sha=%s", sha)
            write_state(status="failed", sha=sha, delivery=delivery)


class Handler(BaseHTTPRequestHandler):
    server_version = "LibertyDeployWebhook/1"

    def log_message(self, message: str, *args: object) -> None:
        LOG.info("client=%s " + message, self.client_address[0], *args)

    def send_json(self, status: HTTPStatus, payload: dict[str, Any]) -> None:
        body = (json.dumps(payload, sort_keys=True) + "\n").encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self) -> None:
        if self.path == "/healthz":
            self.send_json(HTTPStatus.OK, {"status": "ok"})
            return
        self.send_json(HTTPStatus.NOT_FOUND, {"error": "not found"})

    def do_POST(self) -> None:
        if self.path != "/deploy":
            self.send_json(HTTPStatus.NOT_FOUND, {"error": "not found"})
            return

        content_type = self.headers.get_content_type()
        if content_type != "application/json":
            self.send_json(
                HTTPStatus.UNSUPPORTED_MEDIA_TYPE,
                {"error": "Content-Type must be application/json"},
            )
            return

        try:
            content_length = int(self.headers.get("Content-Length", ""))
        except ValueError:
            content_length = -1
        if content_length < 0 or content_length > CONFIG.max_body_bytes:
            self.send_json(HTTPStatus.REQUEST_ENTITY_TOO_LARGE, {"error": "invalid body size"})
            return

        body = self.rfile.read(content_length)
        supplied_signature = self.headers.get("X-Hub-Signature-256", "")
        expected_signature = "sha256=" + hmac.new(CONFIG.secret, body, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(supplied_signature, expected_signature):
            self.send_json(HTTPStatus.UNAUTHORIZED, {"error": "invalid signature"})
            return

        try:
            payload = json.loads(body)
            if not isinstance(payload, dict):
                raise ValueError("payload must be an object")
        except UnicodeDecodeError, json.JSONDecodeError, ValueError:
            self.send_json(HTTPStatus.BAD_REQUEST, {"error": "invalid JSON payload"})
            return

        event = self.headers.get("X-GitHub-Event", "")
        if event == "ping":
            self.send_json(HTTPStatus.OK, {"status": "pong"})
            return

        delivery = self.headers.get("X-GitHub-Delivery", "")
        if not DELIVERY_PATTERN.fullmatch(delivery):
            self.send_json(HTTPStatus.BAD_REQUEST, {"error": "invalid delivery id"})
            return

        try:
            repository, ref, sha = deployment_details(event, payload)
        except ValueError as error:
            self.send_json(HTTPStatus.UNPROCESSABLE_ENTITY, {"error": str(error)})
            return

        if repository != CONFIG.allowed_repository:
            self.send_json(HTTPStatus.FORBIDDEN, {"error": "repository is not allowed"})
            return
        if ref != CONFIG.allowed_ref:
            self.send_json(HTTPStatus.FORBIDDEN, {"error": "ref is not allowed"})
            return
        if not SHA_PATTERN.fullmatch(sha):
            self.send_json(HTTPStatus.BAD_REQUEST, {"error": "invalid commit SHA"})
            return
        if DEPLOYMENT_LOCK.locked():
            self.send_json(HTTPStatus.CONFLICT, {"error": "deployment already running"})
            return
        if not remember_delivery(delivery):
            self.send_json(HTTPStatus.OK, {"status": "already accepted", "sha": sha})
            return

        worker = threading.Thread(
            target=run_deployment,
            args=(sha, delivery),
            name=f"deploy-{delivery}",
            daemon=True,
        )
        worker.start()
        self.send_json(HTTPStatus.ACCEPTED, {"status": "accepted", "sha": sha})


def main() -> None:
    logging.basicConfig(
        level=os.environ.get("LOG_LEVEL", "INFO").upper(),
        format="%(asctime)s %(levelname)s %(name)s %(message)s",
    )
    server = ThreadingHTTPServer((CONFIG.listen_host, CONFIG.listen_port), Handler)
    server.daemon_threads = True
    LOG.info("listening on %s:%s", CONFIG.listen_host, CONFIG.listen_port)
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
