#!/usr/bin/env python3
"""Django's command-line utility for The Liberty Articulator."""

import os
import sys


def main() -> None:
    os.environ.setdefault("DJANGO_SETTINGS_MODULE", "config.settings.development")
    try:
        from django.core.management import execute_from_command_line
    except ImportError as exc:  # pragma: no cover - installation guard
        raise ImportError(
            "Django is not installed. Run `make install` before using manage.py."
        ) from exc
    execute_from_command_line(sys.argv)


if __name__ == "__main__":
    main()
