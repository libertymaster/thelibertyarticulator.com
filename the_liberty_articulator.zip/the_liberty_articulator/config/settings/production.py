"""Hardened production settings for the application tier."""

from django.core.exceptions import ImproperlyConfigured

from .base import *

DEBUG = False

if SECRET_KEY == "unsafe-development-key-change-me-before-deploying":  # nosec B105
    raise ImproperlyConfigured("DJANGO_SECRET_KEY must be set in production")
if not env("DATABASE_URL", default=None):
    raise ImproperlyConfigured("DATABASE_URL must be set in production")

SECURE_SSL_REDIRECT = env.bool("SECURE_SSL_REDIRECT", default=True)
SESSION_COOKIE_SECURE = True
CSRF_COOKIE_SECURE = True
SECURE_HSTS_SECONDS = env.int("SECURE_HSTS_SECONDS", default=31_536_000)
SECURE_HSTS_INCLUDE_SUBDOMAINS = True
SECURE_HSTS_PRELOAD = True
SECURE_PROXY_SSL_HEADER = ("HTTP_X_FORWARDED_PROTO", "https")
USE_X_FORWARDED_HOST = True

if env.bool("USE_R2_STORAGE", default=False):
    _endpoint = env("R2_ENDPOINT_URL")
    _access_key = env("R2_ACCESS_KEY_ID")
    _secret_key = env("R2_SECRET_ACCESS_KEY")
    _bucket = env("R2_BUCKET_NAME", default="libertybucket")
    _domain = env("R2_CUSTOM_DOMAIN", default="assets.thelibertyarticulator.com")
    STORAGES["default"] = {
        "BACKEND": "storages.backends.s3.S3Storage",
        "OPTIONS": {
            "bucket_name": _bucket,
            "access_key": _access_key,
            "secret_key": _secret_key,
            "endpoint_url": _endpoint,
            "custom_domain": _domain,
            "default_acl": None,
            "file_overwrite": False,
            "querystring_auth": False,
        },
    }
    MEDIA_URL = f"https://{_domain}/"
