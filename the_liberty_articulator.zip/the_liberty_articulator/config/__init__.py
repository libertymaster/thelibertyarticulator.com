"""Project configuration package."""

try:
    from .celery import app as celery_app
except ImportError:  # Celery is optional for documentation tooling.
    celery_app = None

__all__ = ("celery_app",)
