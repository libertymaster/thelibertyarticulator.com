"""Root URL configuration."""

from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.contrib.sitemaps.views import sitemap
from django.urls import include, path
from wagtail import urls as wagtail_urls
from wagtail.admin import urls as wagtailadmin_urls
from wagtail.contrib.sitemaps.sitemap_generator import Sitemap
from wagtail.documents import urls as wagtaildocs_urls

from apps.publications.views import home

sitemaps = {"pages": Sitemap}

urlpatterns = [
    path("", home, name="home"),
    path("", include("apps.core.urls")),
    path("publications/", include("apps.publications.urls")),
    path("people/", include("apps.people.urls")),
    path("sources/", include("apps.references.urls")),
    path("series/", include("apps.series.urls")),
    path("search/", include("apps.search.urls")),
    path("accounts/", include("apps.accounts.urls")),
    path("django-admin/", admin.site.urls),
    path("admin/", include(wagtailadmin_urls)),
    path("documents/", include(wagtaildocs_urls)),
    path("sitemap.xml", sitemap, {"sitemaps": sitemaps}, name="sitemap"),
    path("pages/", include(wagtail_urls)),
]

handler404 = "apps.core.views.error_404"
handler500 = "apps.core.views.error_500"

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
